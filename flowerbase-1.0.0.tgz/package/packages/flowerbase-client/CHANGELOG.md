## 0.3.2 (2026-04-02)


### 🩹 Fixes

- updateOne options ([5b16467](https://github.com/flowerforce/flowerbase/commit/5b16467))

## 0.3.1 (2026-03-20)


### 🩹 Fixes

- api call name ([f33a832](https://github.com/flowerforce/flowerbase/commit/f33a832))

## 0.3.0 (2026-03-20)


### 🚀 Features

- add MongoDB Client-Side Field Level Encryption support ([#35](https://github.com/flowerforce/flowerbase/pull/35))

- **monitoring:** Add collapsable editor ([#34](https://github.com/flowerforce/flowerbase/pull/34))


### 🩹 Fixes

- watch operationType delete ([afcbec2](https://github.com/flowerforce/flowerbase/commit/afcbec2))

- propagate runAsSystem ([#41](https://github.com/flowerforce/flowerbase/pull/41))

- add setHeader ([#44](https://github.com/flowerforce/flowerbase/pull/44))

- 401 login ([fd13ff0](https://github.com/flowerforce/flowerbase/commit/fd13ff0))