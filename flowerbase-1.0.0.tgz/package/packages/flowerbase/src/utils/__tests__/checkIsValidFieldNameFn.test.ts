import { ObjectId } from 'bson'
import { User } from '../../fastify'
import { Role } from '../roles/interface'
import { MachineContext } from '../roles/machines/interface'
import { checkIsValidFieldNameFn } from '../roles/machines/read/D/validators'

const mockUser = {} as User
const mockId = new ObjectId()

describe('checkIsValidFieldNameFn', () => {
  beforeEach(() => {
    jest.clearAllMocks()
  })

  it('returns only explicitly allowed fields when no fallback is configured', async () => {
    const mockedRole = {
      name: 'test',
      apply_when: { '%%true': true },
      fields: {
        name: { read: true, write: false },
        email: { read: false, write: true },
        age: { read: false, write: false }
      }
    } as Role
    const context = {
      user: mockUser,
      role: mockedRole,
      params: {
        cursor: { _id: mockId, name: 'Alice', email: 'alice@example.com', age: 25 }
      }
    } as MachineContext

    const result = await checkIsValidFieldNameFn(context)
    expect(result).toEqual({
      _id: mockId,
      name: 'Alice'
    })
  })

  it('uses per-field additional_fields as fallback for unknown fields', async () => {
    const mockedRole = {
      name: 'test',
      apply_when: { '%%true': true },
      fields: {},
      additional_fields: {
        phone: { read: true, write: false },
        address: { read: false, write: true }
      }
    } as Role
    const context = {
      role: mockedRole,
      params: {
        cursor: { _id: mockId, phone: '123456789', address: 'Unknown', city: 'Rome' }
      }
    } as MachineContext

    const result = await checkIsValidFieldNameFn(context)
    expect(result).toEqual({
      _id: mockId,
      phone: '123456789'
    })
  })

  it('keeps fields readable when top-level read is true and the field only defines write rules', async () => {
    const mockedRole = {
      name: 'test',
      apply_when: { '%%true': true },
      read: true,
      fields: {
        avatar: { write: false },
        name: { write: true },
        tags: { write: false },
        updatedAt: { write: true }
      },
      additional_fields: {}
    } as Role
    const context = {
      user: mockUser,
      role: mockedRole,
      params: {
        type: 'read',
        cursor: {
          _id: mockId,
          userId: 'user-1',
          email: 'alice@example.com',
          workspaces: ['workspace-1'],
          avatar: 'avatar.png',
          name: 'Alice',
          tags: ['owner'],
          updatedAt: new Date('2026-03-17T10:00:00.000Z')
        }
      }
    } as MachineContext

    const result = await checkIsValidFieldNameFn(context)
    expect(result).toEqual({
      _id: mockId,
      userId: 'user-1',
      email: 'alice@example.com',
      workspaces: ['workspace-1'],
      avatar: 'avatar.png',
      name: 'Alice',
      tags: ['owner'],
      updatedAt: new Date('2026-03-17T10:00:00.000Z')
    })
  })

  it('always keeps _id in read results even when no field read rule is defined', async () => {
    const mockedRole = {
      name: 'test',
      apply_when: { '%%true': true },
      fields: {
        name: { read: true }
      }
    } as Role
    const context = {
      user: mockUser,
      role: mockedRole,
      params: {
        type: 'read',
        cursor: { _id: mockId, email: 'alice@example.com' }
      }
    } as MachineContext

    const result = await checkIsValidFieldNameFn(context)
    expect(result).toEqual({
      _id: mockId
    })
  })

  it('supports realm-style global additional_fields fallback', async () => {
    const mockedRole = {
      name: 'collaborator',
      apply_when: { '%%true': true },
      fields: {
        roles: { read: true, write: false }
      },
      additional_fields: {
        read: false,
        write: false
      }
    } as Role
    const context = {
      role: mockedRole,
      params: {
        cursor: { roles: ['editor'], email: 'user@example.com' }
      }
    } as MachineContext

    const result = await checkIsValidFieldNameFn(context)
    expect(result).toEqual({
      roles: ['editor']
    })
  })

  it('denies unknown fields when additional_fields global fallback is false', async () => {
    const mockedRole = {
      name: 'test',
      apply_when: { '%%true': true },
      fields: {
        roles: { read: true }
      },
      additional_fields: {
        read: false,
        write: false
      }
    } as Role
    const context = {
      role: mockedRole,
      params: {
        cursor: { email: 'user@example.com' }
      }
    } as MachineContext

    const result = await checkIsValidFieldNameFn(context)
    expect(result).toEqual({})
  })

  it('returns empty object when no field permissions are available', async () => {
    const mockedRole = {
      name: 'test',
      apply_when: { '%%true': true }
    } as Role
    const context = {
      role: mockedRole,
      params: {
        cursor: { _id: mockId, phone: '123456789', address: 'Unknown' }
      }
    } as MachineContext

    const result = await checkIsValidFieldNameFn(context)
    expect(result).toEqual({
      _id: mockId
    })
  })
})
