import { ObjectId } from 'bson'
import _get from 'lodash/get'
import _trimStart from 'lodash/trimStart'
import { Operators, RulesMatcherUtils, RulesObject } from './interface'

const EMPTY_STRING_REGEXP = /^\s*$/
const HEX_24_REGEXP = /^[a-fA-F0-9]{24}$/

const toObjectIdHex = (value: unknown): string | null => {
  if (value instanceof ObjectId) {
    return value.toHexString()
  }

  if (typeof value === 'string') {
    if (!HEX_24_REGEXP.test(value) || !ObjectId.isValid(value)) {
      return null
    }
    return new ObjectId(value).toHexString()
  }

  if (!value || typeof value !== 'object') {
    return null
  }

  const maybeObjectId = value as { _bsontype?: string; toHexString?: () => string }
  if (
    maybeObjectId._bsontype === 'ObjectId' &&
    typeof maybeObjectId.toHexString === 'function'
  ) {
    const hex = maybeObjectId.toHexString()
    return HEX_24_REGEXP.test(hex) ? hex.toLowerCase() : null
  }

  return null
}

const areSemanticallyEqual = (left: unknown, right: unknown): boolean => {
  const leftOid = toObjectIdHex(left)
  const rightOid = toObjectIdHex(right)

  if (leftOid || rightOid) {
    return leftOid !== null && rightOid !== null && leftOid === rightOid
  }

  return left === right
}

const includesWithSemanticEquality = (value: unknown, candidate: unknown): boolean =>
  rulesMatcherUtils
    .forceArray(candidate)
    .some((item) =>
      rulesMatcherUtils
        .forceArray(value)
        .some((sourceItem) =>
          rulesMatcherUtils
            .forceArray(item)
            .some((candidateItem) => areSemanticallyEqual(sourceItem, candidateItem))
        )
    )

const resolveRefPath = (data: unknown, refPath: string, prefix?: string): unknown => {
  const exactMatch = _get(data, refPath, undefined)

  if (exactMatch !== undefined) {
    return exactMatch
  }

  return _get(data, rulesMatcherUtils.getPath(refPath, prefix), undefined)
}

/**
 * Defines a utility object named rulesMatcherUtils, which contains various helper functions used for processing rules and data in a rule-matching context.
 */
const rulesMatcherUtils: RulesMatcherUtils = {
  isNumber: (el) => {
    const num = String(el)
    return !!num.match(/(^-?|^\d+\.)\d+$/)
  },
  rule: (val, data, options) => {
    const { prefix } = options || {}
    const path = Object.keys(val)[0]
    const valueBlock = val
    const pathWithPrefix = rulesMatcherUtils.getPath(path, prefix)
    const valueForKey = _get(data, pathWithPrefix, undefined)
    const { name } = _get(valueBlock, [path], {}) || {}
    const { op, value, opt } = rulesMatcherUtils.getDefaultRule(valueBlock[path])
    const valueRef =
      value && String(value).indexOf('$ref:') === 0
        ? resolveRefPath(data, value.replace('$ref:', ''), prefix)
        : value

    if (!operators[op]) {
      throw new Error(`Error missing operator:${op}`)
    }

    const valid = operators[op]?.(valueForKey, valueRef, opt, data)
    return { valid, name: `${pathWithPrefix}___${name || op}` }
  },
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  getKey: (block: RulesObject<any>, keys, options) => {
    if (Object.prototype.hasOwnProperty.call(block, '$and')) {
      return block.$and.map((item: unknown) =>
        rulesMatcherUtils.getKey(item, keys, options)
      )
    }
    if (Object.prototype.hasOwnProperty.call(block, '$or')) {
      return block.$or.map((item: unknown) =>
        rulesMatcherUtils.getKey(item, keys, options)
      )
    }

    const { prefix } = options || {}
    const path = Object.keys(block)[0]

    const valueBlock = block
    const res = rulesMatcherUtils.getPath(path, prefix)
    const { value } = rulesMatcherUtils.getDefaultRule(valueBlock[path])
    if (value && String(value).indexOf('$ref:') === 0) {
      const refPath = value.replace('$ref:', '')
      keys[refPath] = true
      keys[rulesMatcherUtils.getPath(refPath, prefix)] = true
    }

    return (keys[res] = true)
  },
  isDate: (v) => v instanceof Date,
  isDefined: (v) => v !== null && v !== undefined,
  isObject: (v) => v === Object(v),
  isFunction: (v) => typeof v === 'function',
  isString: (v) => typeof v === 'string',
  getDefaultStringValue: (value) => {
    switch (value) {
      case '$required':
        return { op: '$exists', value: true }
      case '$exists':
        return { op: '$exists', value: true }
      default:
        return { op: '$eq', value }
    }
  },
  getTypeOf: (value) =>
    Array.isArray(value)
      ? 'array'
      : rulesMatcherUtils.isNumber(value)
        ? 'number'
        : value === null
          ? null
          : typeof value,
  getDefaultRule: (value) => {
    const valueType = rulesMatcherUtils.getTypeOf(value)
    switch (valueType) {
      case 'number':
        return { op: '$eq', value }

      case 'string':
        return rulesMatcherUtils.getDefaultStringValue(value)

      case 'boolean':
        return { op: '$exists', value }

      case 'array':
        return { op: '$in', value }

      case 'object':
        return {
          ...value,
          op: value.op || Object.keys(value)[0],
          value: value.value || value[Object.keys(value)[0]]
        }

      default:
        return { op: '$eq', value }
    }
  },
  isEmpty: (value) => {
    // Null and undefined are empty
    if (!rulesMatcherUtils.isDefined(value)) {
      return true
    }

    // functions are non empty
    if (rulesMatcherUtils.isFunction(value)) {
      return false
    }

    /*   if (isBool(value)) {
        return false;
      }
     */
    // Whitespace only strings are empty
    if (rulesMatcherUtils.isString(value)) {
      return EMPTY_STRING_REGEXP.test(value)
    }

    // For arrays we use the length property
    if (Array.isArray(value)) {
      return value.length === 0
    }

    // Dates have no attributes but aren't empty
    if (rulesMatcherUtils.isDate(value)) {
      return false
    }

    // If we find at least one property we consider it non empty
    let attr
    if (rulesMatcherUtils.isObject(value)) {
      for (attr in value) {
        return false
      }
      return true
    }

    return false
  },
  forceArray: (a) => (Array.isArray(a) ? a : [a]),
  getPath: (path, prefix) => {
    if (typeof path !== 'string' || path.length === 0) {
      return ''
    }
    if (path.indexOf('^') === 0) {
      return _trimStart(path, '^')
    }

    // da verificare se è ancora utilizzato
    if (path.indexOf('$') === 0) {
      return path
    }

    return prefix ? `${prefix}.${path}` : path
  },
  // TODO BUG NUMERI CON LETTERE 1asdas o solo

  forceNumber: (el) => {
    if (Array.isArray(el)) {
      return el.length
    }

    if (rulesMatcherUtils.isNumber(String(el))) {
      return parseFloat(String(el))
    }

    // fix perchè un valore false < 1 è true, quindi sbagliato, mentre un valore undefined < 1 è false
    return 0
  },

  checkRule: (block, data, options) => {
    if (
      !Array.isArray(block) &&
      block &&
      Object.prototype.hasOwnProperty.call(block, '$and')
    ) {
      if (block && block['$and'] && !block['$and'].length) return true
      return block['$and'].every((item: RulesObject<Record<string, unknown>>) =>
        rulesMatcherUtils.checkRule(item, data, options)
      )
    }

    if (
      !Array.isArray(block) &&
      block &&
      Object.prototype.hasOwnProperty.call(block, '$or')
    ) {
      if (block && block['$or'] && !block['$or'].length) return true
      return block['$or'].some((item: RulesObject<Record<string, unknown>>) =>
        rulesMatcherUtils.checkRule(item, data, options)
      )
    }

    if (!Array.isArray(block) && block && typeof block === 'object') {
      const keys = Object.keys(block)
      const hasLogicalOperators = keys.some((key) => key === '$and' || key === '$or')
      if (!hasLogicalOperators && keys.length > 1) {
        return keys.every((key) =>
          rulesMatcherUtils.checkRule(
            { [key]: (block as Record<string, unknown>)[key] } as any,
            data,
            options
          )
        )
      }
    }

    const res = rulesMatcherUtils.rule(block, data, options)
    return res.valid
  },

  getKeys: (rules, options) => {
    if (!rules) return null
    if (typeof rules == 'function') return []

    if (!rulesMatcherUtils.forceArray(rules).every((r) => rulesMatcherUtils.isObject(r)))
      return null

    const keys = {}
    const conditions = Array.isArray(rules) ? { $and: rules } : rules
    rulesMatcherUtils.getKey(conditions, keys, options ?? {})
    return Object.keys(keys)
  }
}

/**
 * Defines a set of comparison operators used for matching rules against user input.
 */
export const operators: Operators = {
  $exists: (a, b) => !rulesMatcherUtils.isEmpty(a) === b,
  '%exists': (a, b) => !rulesMatcherUtils.isEmpty(a) === b,

  $eq: (a, b) => areSemanticallyEqual(a, b),

  $ne: (a, b) => !areSemanticallyEqual(a, b),

  $gt: (a, b) => rulesMatcherUtils.forceNumber(a) > parseFloat(b),

  $gte: (a, b) => rulesMatcherUtils.forceNumber(a) >= parseFloat(b),

  $lt: (a, b) => rulesMatcherUtils.forceNumber(a) < parseFloat(b),

  $lte: (a, b) => rulesMatcherUtils.forceNumber(a) <= parseFloat(b),

  $strGt: (a, b) => String(a || '').length > parseFloat(b),

  $strGte: (a, b) => String(a || '').length >= parseFloat(b),

  $strLt: (a, b) => String(a || '').length < parseFloat(b),

  $strLte: (a, b) => String(a || '').length <= parseFloat(b),

  $in: (a, b) => includesWithSemanticEquality(a, b),

  $nin: (a, b) => !includesWithSemanticEquality(a, b),

  $all: (a, b) =>
    rulesMatcherUtils
      .forceArray(b)
      .every((candidate) =>
        rulesMatcherUtils
          .forceArray(a)
          .some((value) =>
            rulesMatcherUtils
              .forceArray(candidate)
              .some((item) => areSemanticallyEqual(value, item))
          )
      ),

  $size: (a, b) => Array.isArray(a) && a.length === parseFloat(b),

  $regex: (a, b, opt) =>
    rulesMatcherUtils
      .forceArray(b)
      .some((c) => (c instanceof RegExp ? c.test(a) : new RegExp(c, opt).test(a))),

  '%stringToOid': (a, b) => {
    const converted = toObjectIdHex(b)
    return converted !== null && areSemanticallyEqual(a, converted)
  },

  '%oidToString': (a, b) => {
    const converted = toObjectIdHex(b)
    return converted !== null && areSemanticallyEqual(a, converted)
  }
}

// export default operators

export default rulesMatcherUtils
