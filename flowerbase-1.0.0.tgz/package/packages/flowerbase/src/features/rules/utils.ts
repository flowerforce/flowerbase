import path from 'node:path'
import { readJsonContent, recursivelyCollectFiles } from '../../utils'
import { Rules, RulesConfig } from './interface'

export const loadRules = async (rootDir = process.cwd()): Promise<Rules> => {
  const rulesRoot = path.join(rootDir, 'data_sources', 'mongodb-atlas')
  const files = recursivelyCollectFiles(rulesRoot)
  const rulesFiles = files.filter((x) => (x as string).endsWith('rules.json'))

  const removeEmptyFieldRules = (rulesConfig: RulesConfig): RulesConfig => {
    const roles = (rulesConfig.roles ?? []).map((role) => {
      const fields = (role as { fields?: Record<string, Record<string, unknown>> }).fields
      if (!fields) return role
      const cleanedFields = Object.fromEntries(
        Object.entries(fields).filter(([, value]) =>
          value && typeof value === 'object' && Object.keys(value).length > 0
        )
      )
      return { ...role, fields: cleanedFields }
    })

    return { ...rulesConfig, roles }
  }

  const rulesByCollection = rulesFiles.reduce((acc, rulesFile) => {
    const filePath = rulesFile
    const collectionRules = removeEmptyFieldRules(readJsonContent(filePath) as RulesConfig)
    acc[collectionRules.collection] = collectionRules

    return acc
  }, {} as Rules)

  return rulesByCollection
}

// export const getNestedPipelines = (pipeline: AggregationPipelineStage[]) => {
//   return pipeline.reduce(
//     (acc, stage) => {
//       const [stageKey] = Object.keys(stage);
//       const stageValue = stage[stageKey as keyof typeof stage];
//       const pipeline = stageValue?.["pipeline"]

//       if (stageKey === '$lookup') {
//         acc.pipelines.push(stageValue);
//         if (pipeline) {
//           const { collections, pipelines } = getNestedPipelines(pipeline);
//           acc.collections.push(...new Set([(stageValue as LookupStage).from, ...collections]));
//           acc.pipelines.push(...pipelines);
//         }
//       }

//       if (stageKey === '$facet') {
//         for (const subPipeline of Object.values(stageValue)) {
//           const { collections, pipelines } = getNestedPipelines(subPipeline as AggregationPipelineStage[]);
//           acc.collections.push(...collections);
//           acc.pipelines.push(...pipelines);
//         }
//       }

//       if (
//         stageKey === '$unionWith' &&
//         typeof stageValue === 'object' &&
//         pipeline
//       ) {
//         const { collections, pipelines } = getNestedPipelines(pipeline);
//         acc.collections.push(...new Set([(stageValue as UnionWithStage).coll, ...collections]));
//         acc.pipelines.push(...pipelines);
//       }

//       return acc;
//     },
//     {
//       collections: [],
//       pipelines: [],
//     } as {
//       collections: string[],
//       pipelines: AggregationPipelineStage[]
//     }
//   );
// }
