import { FastifyInstance } from 'fastify'
import { ObjectId } from 'mongodb'
import { AUTH_CONFIG, AUTH_DB_NAME, DB_NAME, DEFAULT_CONFIG } from '../../../constants'
import { StateManager } from '../../../state'
import { GenerateContext } from '../../../utils/context'
import { hashToken } from '../../../utils/crypto'
import { AUTH_ENDPOINTS } from '../../utils'
import { LoginDto } from './dtos'
import { LOGIN_SCHEMA } from './schema'

/**
 * Controller for handling custom function login.
 * @testable
 * @param {FastifyInstance} app - The Fastify instance.
 */
export async function customFunctionController(app: FastifyInstance) {

  const functionsList = StateManager.select('functions')
  const services = StateManager.select('services')
  const authDb = app.mongo.client.db(AUTH_DB_NAME)
  const customUserDb = app.mongo.client.db(DB_NAME)
  const { authCollection, refreshTokensCollection, userCollection, user_id_field } = AUTH_CONFIG
  const refreshTokenTtlMs = DEFAULT_CONFIG.REFRESH_TOKEN_TTL_DAYS * 24 * 60 * 60 * 1000

  /**
   * Endpoint for user login.
   *
   * @route {POST} /login
   * @param {LoginDto} req - The request object with login data.
   * @returns {Promise<Object>} A promise resolving with access and refresh tokens.
   */
  app.post<LoginDto>(
    AUTH_ENDPOINTS.LOGIN,
    {
      schema: LOGIN_SCHEMA
    },
    async function (req, reply) {
      const customFunctionProvider = AUTH_CONFIG.authProviders?.['custom-function']
      if (!customFunctionProvider || customFunctionProvider.disabled) {
        throw new Error('Custom function authentication disabled')
      }
      const authFunctionName = (customFunctionProvider as { config?: { authFunctionName?: string } })
        .config?.authFunctionName

      if (!authFunctionName || !functionsList[authFunctionName]) {
        throw new Error("Missing Auth Function")
      }

      const {
        ips,
        host,
        hostname,
        url,
        method,
        ip,
        id
      } = req

      type CustomFunctionAuthResult = { id?: string; email?: string }
      const authResult = await GenerateContext({
        args: [
          req.body
        ],
        app,
        rules: {},
        user: {},
        currentFunction: functionsList[authFunctionName],
        functionName: authFunctionName,
        functionsList,
        services,
        request: {
          ips,
          host,
          hostname,
          url,
          method,
          ip,
          id
        }
      }) as CustomFunctionAuthResult


      if (!authResult.id) {
        reply.code(401).send({ message: 'Unauthorized' })
        return
      }

      const email = authResult.email ?? authResult.id
      let authUser = await authDb.collection(authCollection!).findOne({ email })
      if (!authUser) {
        const authUserId = new ObjectId()
        await authDb.collection(authCollection!).insertOne({
          _id: authUserId,
          email,
          status: 'confirmed',
          createdAt: new Date(),
          custom_data: {},
          identities: [
            {
              id: authResult.id.toString(),
              provider_id: authResult.id.toString(),
              provider_type: 'custom-function',
              provider_data: { email }
            }
          ]
        })
        authUser = {
          _id: authUserId,
          email
        }
      }

      const user =
        user_id_field && userCollection
          ? await customUserDb
            .collection(userCollection)
            .findOne({ [user_id_field]: authUser._id.toString() })
          : {}

      const currentUserData = {
        _id: authUser._id,
        user_data: {
          ...(user || {}),
          id: authUser._id.toString(),
          email: authUser.email
        },
        custom_data: {
          ...(user || {})
        }
      }
      const now = new Date()
      const refreshToken = this.createRefreshToken(currentUserData)
      const refreshTokenHash = hashToken(refreshToken)
      await authDb.collection(refreshTokensCollection).insertOne({
        userId: authUser._id,
        tokenHash: refreshTokenHash,
        createdAt: now,
        expiresAt: new Date(Date.now() + refreshTokenTtlMs),
        revokedAt: null
      })
      await authDb.collection(authCollection!).updateOne(
        { _id: authUser._id },
        { $set: { lastLoginAt: now } }
      )
      return {
        access_token: this.createAccessToken(currentUserData),
        refresh_token: refreshToken,
        device_id: '',
        user_id: authUser._id.toString()
      }
    }
  )

}
