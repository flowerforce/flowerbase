import http from 'node:http'
import { AddressInfo } from 'node:net'
import path from 'node:path'
import { EJSON } from 'bson'
import { FastifyInstance } from 'fastify'
import { DeleteResult, Document, MongoClient, ObjectId } from 'mongodb'
import type { User } from '../../packages/flowerbase/src/auth/dtos'
import { API_VERSION, AUTH_CONFIG } from '../../packages/flowerbase/src/constants'
import { hashPassword } from '../../packages/flowerbase/src/utils/crypto'
import { registerMongoAtlasE2eSetup } from './mongodb-atlas.rules.e2e.setup'

jest.setTimeout(120000)

const APP_ROOT = path.join(__dirname, 'app')
const DB_NAME = 'flowerbase-e2e'
const TODO_COLLECTION = 'todos'
const USER_COLLECTION = 'users'
const TEAM_DOCS_COLLECTION = 'teamDocs'
const OID_EQ_COLLECTION = 'oidEqDocs'
const OID_STRING_TO_OID_COLLECTION = 'oidStringToOidDocs'
const OID_TO_STRING_COLLECTION = 'oidToStringDocs'
const ACTIVITIES_COLLECTION = 'activities'
const COUNTERS_COLLECTION = 'counters'
const COUNTERS_APPLY_WHEN_FUNCTION_COLLECTION = 'countersApplyWhenFunction'
const UPLOADS_COLLECTION = 'uploads'
const INSERT_ONLY_COLLECTION = 'insertOnlyDocs'
const APP_SETTINGS_COLLECTION = 'app_settings'
const INTERNAL_CONTACTS_COLLECTION = 'internalContacts'
const INTERNAL_READ_CONTACTS_COLLECTION = 'internalReadContacts'
const INVENTORY_COLLECTION = 'inventory'
const INVENTORY_HIDDEN_COLLECTION = 'inventoryHidden'
const TRIGGER_ITEMS_INSERT_COLLECTION = 'trigger_items_insert'
const TRIGGER_ITEMS_UPDATE_COLLECTION = 'trigger_items_update'
const TRIGGER_ITEMS_DELETE_COLLECTION = 'trigger_items_delete'
const FILTERED_TRIGGER_ITEMS_COLLECTION = 'trigger_items_filtered'
const AUTH_USERS_COLLECTION = 'auth_users'
const RESET_PASSWORD_COLLECTION = 'reset_password_requests'
const FILTERED_TRIGGER_EVENTS_COLLECTION = 'filteredTriggerEvents'
const FILTERED_UPDATE_TRIGGER_EVENTS_COLLECTION = 'filteredUpdateTriggerEvents'
const MANAGE_REPLICA_SET = process.env.MANAGE_REPLICA_SET === 'true'
const REPLICA_SET_NAME = process.env.REPLICA_SET_NAME ?? 'rs0'
const REPLICA_SET_HOST = process.env.REPLICA_SET_HOST ?? 'mongo:27017'
const DEFAULT_DB_URL = 'mongodb://localhost:27017'
const resolveMongoUrl = () => {
  const value = process.env.DB_CONNECTION_STRING?.trim()
  return value && value.length > 0 ? value : DEFAULT_DB_URL
}

type TestUser = User & {
  id: string
  role?: string
  email: string
  custom_data?: {
    type?: string
    key?: string
    accountRole?: string
    company?: string
    workspaces: string[]
    adminIn?: string[]
  }
}

const todoIds = {
  ownerFirst: new ObjectId('000000000000000000000001'),
  ownerSecond: new ObjectId('000000000000000000000002'),
  otherUser: new ObjectId('000000000000000000000003')
}

const userIds = {
  owner: new ObjectId('000000000000000000000010'),
  guest: new ObjectId('000000000000000000000011')
}

const projectIds = {
  ownerProject: new ObjectId('000000000000000000000020'),
  guestProject: new ObjectId('000000000000000000000021')
}
const oidDocIds = {
  ownerCompany: new ObjectId('000000000000000000000040'),
  otherCompany: new ObjectId('000000000000000000000041')
}
const teamDocIds = {
  collaboratorDoc: new ObjectId('000000000000000000000022')
}

const logIds = {
  activeOwner: new ObjectId('000000000000000000000030'),
  inactiveOwner: new ObjectId('000000000000000000000031'),
  activeGuest: new ObjectId('000000000000000000000032')
}

const activityIds = {
  ownerPrivate: new ObjectId('000000000000000000000101'),
  ownerPublic: new ObjectId('000000000000000000000102'),
  guestPublic: new ObjectId('000000000000000000000103')
}

const counterIds = {
  ownerOnly: new ObjectId('000000000000000000000201'),
  workspaceAll: new ObjectId('000000000000000000000202'),
  visibilityUsers: new ObjectId('000000000000000000000203'),
  adminOnly: new ObjectId('000000000000000000000204')
}
const counterApplyWhenFunctionIds = {
  adminWorkspaceDoc: new ObjectId('000000000000000000000205'),
  guestWorkspaceDoc: new ObjectId('000000000000000000000206')
}
const uploadIds = {
  owner: new ObjectId('000000000000000000000301'),
  guest: new ObjectId('000000000000000000000302')
}
const appSettingsIds = {
  ownerGeneral: new ObjectId('000000000000000000000501')
}
const inventoryIds = {
  ownerApple: new ObjectId('000000000000000000000601'),
  ownerBanana: new ObjectId('000000000000000000000602'),
  otherOrange: new ObjectId('000000000000000000000603')
}
const inventoryHiddenIds = {
  ownerApple: new ObjectId('000000000000000000000611'),
  ownerBanana: new ObjectId('000000000000000000000612'),
  otherOrange: new ObjectId('000000000000000000000613')
}
const authUserIds = {
  owner: new ObjectId('000000000000000000000090'),
  guest: new ObjectId('000000000000000000000091'),
  admin: new ObjectId('000000000000000000000092')
}
const ownerUser: TestUser = {
  id: authUserIds.owner.toString(),
  email: 'owner@example.com',
  role: 'owner',
  custom_data: {
    role: 'owner',
    type: 'internal',
    accountRole: 'collaborator',
    company: oidDocIds.ownerCompany.toHexString(),
    key: 'publisher-owner',
    workspaces: ['workspace-1'],
    adminIn: ['workspace-1']
  }
} as TestUser
const guestUser: TestUser = {
  id: authUserIds.guest.toString(),
  email: 'guest@example.com',
  role: 'guest',
  custom_data: {
    role: 'guest',
    type: 'guest',
    company: oidDocIds.otherCompany.toHexString(),
    key: 'publisher-guest',
    workspaces: ['workspace-2'],
    adminIn: []
  }
} as TestUser
const adminUser: TestUser = {
  id: authUserIds.admin.toString(),
  email: 'admin@example.com',
  role: 'admin',
  custom_data: {
    role: 'admin',
    type: 'admin',
    company: new ObjectId('000000000000000000000042').toHexString(),
    key: 'publisher-admin',
    workspaces: ['workspace-1', 'workspace-2'],
    adminIn: ['workspace-1', 'workspace-2']
  }
} as TestUser
const TRIGGER_EVENTS_COLLECTION = 'triggerEvents'
const PROVIDER_TRIGGER_EVENTS_COLLECTION = 'providerTriggerEvents'
const PROJECT_ID = 'flowerbase-e2e'
const FUNCTION_CALL_URL = `${API_VERSION}/app/${PROJECT_ID}/functions/call`
const TOKEN_MAP: Record<string, string> = {}

const serializeValue = (value: unknown) => {
  if (value === undefined) return undefined
  const serialized = EJSON.stringify(value)
  try {
    return JSON.parse(serialized)
  } catch {
    return serialized
  }
}

const getTokenFor = (user: TestUser | null) => {
  if (!user) return undefined
  return TOKEN_MAP[user.id]
}

const callServiceOperation = async ({
  collection,
  method,
  user,
  query,
  filter,
  update,
  projection,
  document,
  pipeline,
  options
}: {
  collection: string
  method:
  | 'find'
  | 'findOne'
  | 'count'
  | 'countDocuments'
  | 'findOneAndUpdate'
  | 'deleteOne'
  | 'deleteMany'
  | 'insertOne'
  | 'updateOne'
  | 'aggregate'
  user: TestUser | null
  query?: Document
  filter?: Document
  update?: Document
  projection?: Document
  document?: Document
  options?: Document
  pipeline?: Document[]
}) => {
  const fastify = appInstance
  if (!fastify) {
    throw new Error('App instance not initialized')
  }

  const payload = {
    name: method,
    arguments: [
      {
        database: DB_NAME,
        collection,
        query: serializeValue(query),
        filter: serializeValue(filter),
        update: serializeValue(update),
        projection: serializeValue(projection),
        document: serializeValue(document),
        pipeline: pipeline?.map((stage) => serializeValue(stage)),
        options: serializeValue(options)
      }
    ],
    service: 'mongodb-atlas'
  }

  const headers: Record<string, string> = {}
  const token = getTokenFor(user)
  if (!token && user) {
    throw new Error(`Missing token for ${user.id}`)
  }
  if (token) {
    headers.authorization = `Bearer ${token}`
  }

  const response = await fastify.inject({
    method: 'POST',
    url: FUNCTION_CALL_URL,
    headers,
    payload
  })

  if (response.statusCode >= 400) {
    const body = response.json()
    const message =
      body && typeof body === 'object' && 'message' in body
        ? (body as { message?: string }).message
        : undefined
    throw new Error(message ?? response.payload ?? 'failed to execute service operation')
  }

  return EJSON.deserialize(response.json())
}

const createCollectionProxy = (collection: string, user: TestUser | null) => ({
  find: (query: Document = {}, projection?: Document, options?: Document) => ({
    toArray: async () =>
      callServiceOperation({
        collection,
        method: 'find',
        user,
        query,
        projection,
        options
      })
  }),
  aggregate: (pipeline: Document[] = []) => ({
    toArray: async () =>
      callServiceOperation({ collection, method: 'aggregate', user, pipeline })
  }),
  findOne: (query: Document = {}, projection?: Document, options?: Document) =>
    callServiceOperation({
      collection,
      method: 'findOne',
      user,
      query,
      projection,
      options
    }),
  count: (query: Document = {}, options?: Document) =>
    callServiceOperation({ collection, method: 'count', user, query, options }),
  countDocuments: (query: Document = {}, options?: Document) =>
    callServiceOperation({ collection, method: 'countDocuments', user, query, options }),
  insertOne: (document: Document) =>
    callServiceOperation({ collection, method: 'insertOne', user, document }),
  updateOne: (query: Document, update: Document, options?: Document) =>
    callServiceOperation({ collection, method: 'updateOne', user, query, update, options }),
  findOneAndUpdate: (query: Document, update: Document) =>
    callServiceOperation({ collection, method: 'findOneAndUpdate', user, query, update }),
  deleteOne: (query: Document, options?: Document) =>
    callServiceOperation({ collection, method: 'deleteOne', user, query, options }),
  deleteMany: (query: Document = {}, options?: Document) =>
    callServiceOperation({ collection, method: 'deleteMany', user, query, options })
})

const getTodosCollection = (user: TestUser | null) =>
  createCollectionProxy(TODO_COLLECTION, user)
const getUsersCollection = (user: TestUser | null) =>
  createCollectionProxy(USER_COLLECTION, user)
const getTeamDocsCollection = (user: TestUser | null) =>
  createCollectionProxy(TEAM_DOCS_COLLECTION, user)
const getOidEqCollection = (user: TestUser | null) =>
  createCollectionProxy(OID_EQ_COLLECTION, user)
const getOidStringToOidCollection = (user: TestUser | null) =>
  createCollectionProxy(OID_STRING_TO_OID_COLLECTION, user)
const getOidToStringCollection = (user: TestUser | null) =>
  createCollectionProxy(OID_TO_STRING_COLLECTION, user)
const getAuthUsersCollection = (user: TestUser | null) =>
  createCollectionProxy(AUTH_USERS_COLLECTION, user)
const getProjectsCollection = (user: TestUser | null) =>
  createCollectionProxy('projects', user)
const getActivityLogsCollection = (user: TestUser | null) =>
  createCollectionProxy('activityLogs', user)
const getActivitiesCollection = (user: TestUser | null) =>
  createCollectionProxy(ACTIVITIES_COLLECTION, user)
const getCountersCollection = (user: TestUser | null) =>
  createCollectionProxy(COUNTERS_COLLECTION, user)
const getCountersApplyWhenFunctionCollection = (user: TestUser | null) =>
  createCollectionProxy(COUNTERS_APPLY_WHEN_FUNCTION_COLLECTION, user)
const getUploadsCollection = (user: TestUser | null) =>
  createCollectionProxy(UPLOADS_COLLECTION, user)
const getInsertOnlyCollection = (user: TestUser | null) =>
  createCollectionProxy(INSERT_ONLY_COLLECTION, user)
const getAppSettingsCollection = (user: TestUser | null) =>
  createCollectionProxy(APP_SETTINGS_COLLECTION, user)
const getInternalContactsCollection = (user: TestUser | null) =>
  createCollectionProxy(INTERNAL_CONTACTS_COLLECTION, user)
const getInternalReadContactsCollection = (user: TestUser | null) =>
  createCollectionProxy(INTERNAL_READ_CONTACTS_COLLECTION, user)
const getInventoryCollection = (user: TestUser | null) =>
  createCollectionProxy(INVENTORY_COLLECTION, user)
const getInventoryHiddenCollection = (user: TestUser | null) =>
  createCollectionProxy(INVENTORY_HIDDEN_COLLECTION, user)

const registerAccessToken = (user: TestUser, authId: ObjectId) => {
  if (!appInstance) {
    throw new Error('App instance not initialized')
  }

  const customData = user.custom_data ?? {}
  const userData = {
    _id: authId,
    id: authId.toString(),
    email: user.email,
    role: user.role,
    custom_data: customData,
    ...customData
  }

  const payload = {
    _id: authId,
    email: user.email,
    user_data: userData
  } as Parameters<NonNullable<typeof appInstance>['createAccessToken']>[0]
  const token = appInstance.createAccessToken(payload)

  TOKEN_MAP[user.id] = token
}

type TodoDoc = Document & { userId: string }
type ProjectDoc = Document & {
  ownerId: string
  summary: string
  secretNotes?: string
  internalCode?: string
}
type TeamDoc = Document & {
  ownerId: string
  roles: string[]
}
type ActivityLogDoc = Document & {
  status: string
  ownerId: string
}
type UserDoc = Document & {
  userId: string
  workspaces: string[]
  avatar: string
  name: string
  tags: string[]
  updatedAt: Date
}
type ActivityDoc = Document & {
  ownerId: string
  workspace: string
  visibility: {
    type: string
    users?: string[]
  }
  title: string
}
type CounterDoc = Document & {
  ownerId: string
  workspace: string
  visibility: {
    type: string
    users?: string[]
  }
  value: number
}
type CounterApplyWhenFunctionDoc = Document & {
  owner: string
  workspace: string
  visibility: {
    type: string
    users?: string[]
  }
  value: number
}
type UploadDoc = Document & {
  publisher: string
  status: string
}
type AppSettingsDoc = Document & {
  scope: string
  ownerUserId?: string
  updatedAt?: string
  createdAt?: string
  locale?: string
}

let client: MongoClient
let appInstance: FastifyInstance | undefined
let originalMainPath: string | undefined

const resetCollections = async () => {
  const db = client.db(DB_NAME)
  await Promise.all([
    db.collection(TODO_COLLECTION).deleteMany({}),
    db.collection(USER_COLLECTION).deleteMany({}),
    db.collection(TEAM_DOCS_COLLECTION).deleteMany({}),
    db.collection(OID_EQ_COLLECTION).deleteMany({}),
    db.collection(OID_STRING_TO_OID_COLLECTION).deleteMany({}),
    db.collection(OID_TO_STRING_COLLECTION).deleteMany({}),
    db.collection('projects').deleteMany({}),
    db.collection('activityLogs').deleteMany({}),
    db.collection(ACTIVITIES_COLLECTION).deleteMany({}),
    db.collection(COUNTERS_COLLECTION).deleteMany({}),
    db.collection(COUNTERS_APPLY_WHEN_FUNCTION_COLLECTION).deleteMany({}),
    db.collection(UPLOADS_COLLECTION).deleteMany({}),
    db.collection(INSERT_ONLY_COLLECTION).deleteMany({}),
    db.collection(APP_SETTINGS_COLLECTION).deleteMany({}),
    db.collection(INTERNAL_CONTACTS_COLLECTION).deleteMany({}),
    db.collection(INTERNAL_READ_CONTACTS_COLLECTION).deleteMany({}),
    db.collection(INVENTORY_COLLECTION).deleteMany({}),
    db.collection(INVENTORY_HIDDEN_COLLECTION).deleteMany({}),
    db.collection(AUTH_USERS_COLLECTION).deleteMany({}),
    db.collection(AUTH_CONFIG.refreshTokensCollection).deleteMany({}),
    db.collection(RESET_PASSWORD_COLLECTION).deleteMany({}),
    db.collection(TRIGGER_ITEMS_INSERT_COLLECTION).deleteMany({}),
    db.collection(TRIGGER_ITEMS_UPDATE_COLLECTION).deleteMany({}),
    db.collection(TRIGGER_ITEMS_DELETE_COLLECTION).deleteMany({}),
    db.collection(FILTERED_TRIGGER_ITEMS_COLLECTION).deleteMany({}),
    db.collection(TRIGGER_EVENTS_COLLECTION).deleteMany({}),
    db.collection(PROVIDER_TRIGGER_EVENTS_COLLECTION).deleteMany({}),
    db.collection(FILTERED_TRIGGER_EVENTS_COLLECTION).deleteMany({}),
    db.collection(FILTERED_UPDATE_TRIGGER_EVENTS_COLLECTION).deleteMany({})
  ])

  await db.collection(TODO_COLLECTION).insertMany([
    {
      _id: todoIds.ownerFirst,
      title: 'Owner task 1',
      userId: ownerUser.id,
      sensitive: 'redacted'
    },
    {
      _id: todoIds.ownerSecond,
      title: 'Owner task 2',
      userId: ownerUser.id,
      sensitive: 'redacted'
    },
    {
      _id: todoIds.otherUser,
      title: 'Other user task',
      userId: guestUser.id,
      sensitive: 'redacted'
    }
  ])

  await db.collection(USER_COLLECTION).insertMany([
    {
      _id: userIds.owner,
      userId: ownerUser.id,
      id: authUserIds.owner.toString(),
      email: 'owner@example.com',
      password: 'top-secret',
      workspaces: ['workspace-1'],
      avatar: 'owner.png',
      name: 'Owner name',
      tags: ['owner'],
      updatedAt: new Date()
    },
    {
      _id: userIds.guest,
      userId: guestUser.id,
      id: authUserIds.guest.toString(),
      email: 'guest@example.com',
      password: 'safe-secret',
      workspaces: ['workspace-2'],
      avatar: 'guest.png',
      name: 'Guest name',
      tags: ['guest'],
      updatedAt: new Date()
    }
  ])

  await db.collection('projects').insertMany([
    {
      _id: projectIds.ownerProject,
      ownerId: ownerUser.id,
      name: 'Owner project',
      summary: 'Owner summary',
      secretNotes: 'top secret',
      internalCode: 'XYZ123'
    },
    {
      _id: projectIds.guestProject,
      ownerId: guestUser.id,
      name: 'Guest project',
      summary: 'Guest summary',
      secretNotes: 'guest secret',
      internalCode: 'ABC987'
    }
  ])

  await db.collection(TEAM_DOCS_COLLECTION).insertMany([
    {
      _id: teamDocIds.collaboratorDoc,
      ownerId: ownerUser.id,
      roles: ['editor'],
      email: 'collaborator@example.com',
      status: 'active'
    }
  ])

  await db.collection(OID_EQ_COLLECTION).insertMany([
    {
      _id: oidDocIds.ownerCompany,
      name: 'Owner company doc'
    },
    {
      _id: oidDocIds.otherCompany,
      name: 'Other company doc'
    }
  ])

  await db.collection(OID_STRING_TO_OID_COLLECTION).insertMany([
    {
      _id: oidDocIds.ownerCompany,
      name: 'Owner company doc'
    },
    {
      _id: oidDocIds.otherCompany,
      name: 'Other company doc'
    }
  ])

  await db.collection(OID_TO_STRING_COLLECTION).insertMany([
    {
      _id: new ObjectId('000000000000000000000043'),
      ownerAuthId: ownerUser.id,
      name: 'Owned by owner auth id'
    },
    {
      _id: new ObjectId('000000000000000000000044'),
      ownerAuthId: guestUser.id,
      name: 'Owned by guest auth id'
    }
  ])

  await db.collection('activityLogs').insertMany([
    {
      _id: logIds.activeOwner,
      message: 'Owner active log',
      status: 'active',
      ownerId: ownerUser.id
    },
    {
      _id: logIds.inactiveOwner,
      message: 'Owner inactive log',
      status: 'inactive',
      ownerId: ownerUser.id
    },
    {
      _id: logIds.activeGuest,
      message: 'Guest active log',
      status: 'active',
      ownerId: guestUser.id
    }
  ])

  await db.collection(ACTIVITIES_COLLECTION).insertMany([
    {
      _id: activityIds.ownerPrivate,
      title: 'Private owner activity',
      ownerId: ownerUser.id,
      workspace: 'workspace-1',
      visibility: {
        type: 'onlyme'
      }
    },
    {
      _id: activityIds.ownerPublic,
      title: 'Shared activity',
      ownerId: 'user-three',
      workspace: 'workspace-1',
      visibility: {
        type: 'team'
      }
    },
    {
      _id: activityIds.guestPublic,
      title: 'Guest workspace activity',
      ownerId: guestUser.id,
      workspace: 'workspace-2',
      visibility: {
        type: 'group'
      }
    }
  ])

  await db.collection(COUNTERS_COLLECTION).insertMany([
    {
      _id: counterIds.ownerOnly,
      ownerId: ownerUser.id,
      workspace: 'workspace-1',
      value: 100,
      visibility: {
        type: 'onlyme'
      }
    },
    {
      _id: counterIds.workspaceAll,
      ownerId: 'user-three',
      workspace: 'workspace-1',
      value: 200,
      visibility: {
        type: 'all'
      }
    },
    {
      _id: counterIds.visibilityUsers,
      ownerId: 'user-four',
      workspace: 'workspace-2',
      value: 300,
      visibility: {
        type: 'private',
        users: [guestUser.id]
      }
    },
    {
      _id: counterIds.adminOnly,
      ownerId: 'user-five',
      workspace: 'workspace-1',
      value: 400,
      visibility: {
        type: 'private'
      }
    }
  ])

  await db.collection(COUNTERS_APPLY_WHEN_FUNCTION_COLLECTION).insertMany([
    {
      _id: counterApplyWhenFunctionIds.adminWorkspaceDoc,
      owner: 'user-external',
      workspace: 'workspace-1',
      value: 610,
      visibility: {
        type: 'private'
      }
    },
    {
      _id: counterApplyWhenFunctionIds.guestWorkspaceDoc,
      owner: guestUser.id,
      workspace: 'workspace-2',
      value: 710,
      visibility: {
        type: 'onlyme'
      }
    }
  ])

  await db.collection(UPLOADS_COLLECTION).insertMany([
    {
      _id: uploadIds.owner,
      publisher: ownerUser.custom_data?.key,
      status: 'pending'
    },
    {
      _id: uploadIds.guest,
      publisher: guestUser.custom_data?.key,
      status: 'pending'
    }
  ])

  await db.collection(APP_SETTINGS_COLLECTION).insertMany([
    {
      _id: appSettingsIds.ownerGeneral,
      scope: 'workspace',
      ownerUserId: ownerUser.id,
      locale: 'it-IT',
      createdAt: '2026-01-01T00:00:00.000Z',
      updatedAt: '2026-01-01T00:00:00.000Z'
    }
  ])

  await db.collection(INTERNAL_CONTACTS_COLLECTION).insertMany([
    {
      _id: new ObjectId('000000000000000000000350'),
      name: 'Internal HQ',
      address: 'Via Roma 1',
      phone: '+39-123456'
    }
  ])

  await db.collection(INTERNAL_READ_CONTACTS_COLLECTION).insertMany([
    {
      _id: new ObjectId('000000000000000000000351'),
      name: 'Read HQ',
      address: 'Via Milano 2',
      phone: '+39-654321'
    }
  ])

  await db.collection(INVENTORY_COLLECTION).insertMany([
    {
      _id: inventoryIds.ownerApple,
      item: 'apple',
      status: 'A',
      ownerId: ownerUser.id,
      price: 1.99,
      secretCost: 0.42,
      instock: { qty: 120, warehouse: 'north' }
    },
    {
      _id: inventoryIds.ownerBanana,
      item: 'banana',
      status: 'B',
      ownerId: ownerUser.id,
      price: 0.49,
      secretCost: 0.1,
      instock: { qty: 40, warehouse: 'south' }
    },
    {
      _id: inventoryIds.otherOrange,
      item: 'orange',
      status: 'A',
      ownerId: guestUser.id,
      price: 2.5,
      secretCost: 0.9,
      instock: { qty: 10, warehouse: 'east' }
    }
  ])

  await db.collection(INVENTORY_HIDDEN_COLLECTION).insertMany([
    {
      _id: inventoryHiddenIds.ownerApple,
      item: 'apple',
      status: 'A',
      ownerId: ownerUser.id,
      price: 1.99,
      instock: { qty: 120, warehouse: 'north' }
    },
    {
      _id: inventoryHiddenIds.ownerBanana,
      item: 'banana',
      status: 'B',
      ownerId: ownerUser.id,
      price: 0.49,
      instock: { qty: 40, warehouse: 'south' }
    },
    {
      _id: inventoryHiddenIds.otherOrange,
      item: 'orange',
      status: 'A',
      ownerId: guestUser.id,
      price: 2.5,
      instock: { qty: 10, warehouse: 'east' }
    }
  ])

  const [ownerPassword, guestPassword, adminPassword] = await Promise.all([
    hashPassword('top-secret'),
    hashPassword('safe-secret'),
    hashPassword('admin-secret')
  ])

  await db.collection(AUTH_USERS_COLLECTION).insertMany([
    {
      _id: authUserIds.owner,
      email: 'auth-owner@example.com',
      password: ownerPassword,
      status: 'confirmed',
      createdAt: new Date(),
      userId: ownerUser.id
    },
    {
      _id: authUserIds.guest,
      email: 'auth-guest@example.com',
      password: guestPassword,
      status: 'confirmed',
      createdAt: new Date(),
      userId: guestUser.id
    },
    {
      _id: authUserIds.admin,
      email: 'auth-admin@example.com',
      password: adminPassword,
      status: 'confirmed',
      createdAt: new Date(),
      userId: adminUser.id
    }
  ])
}

const ensureFilteredTriggerCollections = async () => {
  const db = client.db(DB_NAME)

  const recreateCollection = async (
    name: string,
    options?: Parameters<typeof db.createCollection>[1]
  ) => {
    try {
      await db.collection(name).drop()
    } catch {
      // ignore if collection does not exist
    }

    await db.createCollection(name, options)
  }

  await recreateCollection(FILTERED_TRIGGER_EVENTS_COLLECTION)
  await recreateCollection(FILTERED_UPDATE_TRIGGER_EVENTS_COLLECTION)
  await recreateCollection(FILTERED_TRIGGER_ITEMS_COLLECTION, {
    changeStreamPreAndPostImages: { enabled: true }
  })
}

const dropReplicaSetHint = (mongoUrl: string) => {
  try {
    const url = new URL(mongoUrl)
    url.searchParams.delete('replicaSet')
    const normalized = url.toString()
    return normalized.endsWith('?') ? normalized.slice(0, -1) : normalized
  } catch {
    return mongoUrl.split('?')[0]
  }
}

const waitForTriggerEvent = async (documentId: string) => {
  const collection = client.db(DB_NAME).collection(TRIGGER_EVENTS_COLLECTION)
  for (let attempt = 0; attempt < 10; attempt++) {
    const record = await collection.findOne({ documentId })
    if (record) {
      return record
    }
    await new Promise((resolve) => setTimeout(resolve, 250))
  }
  return null
}

const waitForTriggerEventType = async (documentId: string, type: string) => {
  const collection = client.db(DB_NAME).collection(TRIGGER_EVENTS_COLLECTION)
  for (let attempt = 0; attempt < 10; attempt++) {
    const record = await collection.findOne({ documentId, type })
    if (record) {
      return record
    }
    await new Promise((resolve) => setTimeout(resolve, 250))
  }
  return null
}

const waitForFilteredTriggerEvent = async (documentId: string) => {
  const collection = client.db(DB_NAME).collection(FILTERED_TRIGGER_EVENTS_COLLECTION)
  for (let attempt = 0; attempt < 10; attempt++) {
    const record = await collection.findOne({ documentId })
    if (record) {
      return record
    }
    await new Promise((resolve) => setTimeout(resolve, 250))
  }
  return null
}

const waitForFilteredUpdateTriggerEvent = async (documentId: string) => {
  const collection = client
    .db(DB_NAME)
    .collection(FILTERED_UPDATE_TRIGGER_EVENTS_COLLECTION)
  for (let attempt = 0; attempt < 10; attempt++) {
    const record = await collection.findOne({ documentId })
    if (record) {
      return record
    }
    await new Promise((resolve) => setTimeout(resolve, 250))
  }
  return null
}

type WatchEvent = Document & {
  operationType?: string
  fullDocument?: Document
  documentKey?: {
    _id?: unknown
  }
}

type WatchConnection = {
  nextEvent: (timeoutMs?: number) => Promise<WatchEvent>
  expectNoEvent: (timeoutMs?: number) => Promise<void>
  close: () => Promise<void>
}

const getServerPort = () => {
  if (!appInstance) {
    throw new Error('App instance not initialized')
  }
  const address = appInstance.server.address()
  if (!address || typeof address === 'string') {
    throw new Error('Unable to resolve app server address')
  }
  return (address as AddressInfo).port
}

const openWatchConnection = async ({
  user,
  collection,
  filter
}: {
  user: TestUser
  collection: string
  filter?: Document
}): Promise<WatchConnection> => {
  const token = getTokenFor(user)
  if (!token) {
    throw new Error(`Missing token for ${user.id}`)
  }

  const payload = {
    name: 'watch',
    service: 'mongodb-atlas',
    arguments: [
      {
        database: DB_NAME,
        collection,
        ...(filter ? { filter } : {})
      }
    ]
  }
  const encoded = Buffer.from(EJSON.stringify(payload)).toString('base64')
  const port = getServerPort()
  const path = `${FUNCTION_CALL_URL}?baas_request=${encodeURIComponent(encoded)}`

  return new Promise<WatchConnection>((resolve, reject) => {
    const queue: WatchEvent[] = []
    const waiters: Array<(event: WatchEvent) => void> = []
    let streamEnded = false
    let settled = false
    let buffer = ''

    const emitEvent = (event: WatchEvent) => {
      const waiter = waiters.shift()
      if (waiter) {
        waiter(event)
        return
      }
      queue.push(event)
    }

    const parseSseChunk = (chunk: string) => {
      buffer += chunk
      while (true) {
        const boundary = buffer.indexOf('\n\n')
        if (boundary === -1) break
        const rawEvent = buffer.slice(0, boundary)
        buffer = buffer.slice(boundary + 2)
        const lines = rawEvent.split('\n')
        const dataLines = lines
          .filter((line) => line.startsWith('data:'))
          .map((line) => line.slice(5).trim())
          .filter(Boolean)

        if (!dataLines.length) continue
        const dataPayload = dataLines.join('\n')
        try {
          const parsed = EJSON.deserialize(JSON.parse(dataPayload)) as WatchEvent
          emitEvent(parsed)
        } catch {
          // Ignore malformed SSE payloads in tests.
        }
      }
    }

    const req = http.request(
      {
        host: '127.0.0.1',
        port,
        method: 'GET',
        path,
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'text/event-stream'
        }
      },
      (response) => {
        if (response.statusCode !== 200) {
          if (!settled) {
            settled = true
            reject(new Error(`watch failed with status ${response.statusCode}`))
          }
          return
        }

        response.setEncoding('utf8')
        response.on('data', parseSseChunk)
        response.on('end', () => {
          streamEnded = true
        })
        response.on('error', (error) => {
          if (!settled) {
            settled = true
            reject(error)
          }
        })

        if (!settled) {
          settled = true
          resolve({
            nextEvent: (timeoutMs = 5000) =>
              new Promise<WatchEvent>((resolveEvent, rejectEvent) => {
                const immediate = queue.shift()
                if (immediate) {
                  resolveEvent(immediate)
                  return
                }
                if (streamEnded) {
                  rejectEvent(new Error('watch stream ended before receiving an event'))
                  return
                }
                const timer = setTimeout(() => {
                  const index = waiters.indexOf(waitForEvent)
                  if (index >= 0) waiters.splice(index, 1)
                  rejectEvent(
                    new Error(`Timed out waiting for watch event (${timeoutMs}ms)`)
                  )
                }, timeoutMs)
                const waitForEvent = (event: WatchEvent) => {
                  clearTimeout(timer)
                  resolveEvent(event)
                }
                waiters.push(waitForEvent)
              }),
            expectNoEvent: async (timeoutMs = 800) => {
              const immediate = queue.shift()
              if (immediate) {
                throw new Error(`Unexpected watch event: ${JSON.stringify(immediate)}`)
              }
              await new Promise((resolveDelay) => setTimeout(resolveDelay, timeoutMs))
              const late = queue.shift()
              if (late) {
                throw new Error(`Unexpected watch event: ${JSON.stringify(late)}`)
              }
            },
            close: async () => {
              streamEnded = true
              req.destroy()
            }
          })
        }
      }
    )

    req.on('error', (error) => {
      if (!settled) {
        settled = true
        reject(error)
      }
    })

    req.end()
  })
}

const isReplicaSetNotInitializedError = (error: unknown) => {
  if (!(error instanceof Error)) {
    return false
  }
  const message = error.message.toLowerCase()
  return (
    message.includes('not yet initialized') ||
    message.includes('no replset config has been received') ||
    message.includes('no host described in new configuration') ||
    message.includes('not yet a member of a replset') ||
    message.includes('replset not yet initialized') ||
    ('code' in error && (error as { code?: number }).code === 94) ||
    ('codeName' in error &&
      (error as { codeName?: string }).codeName === 'NotYetInitialized')
  )
}

const ensureReplicaSet = async (client: MongoClient) => {
  const adminDb = client.db('admin')
  let initiated = false
  for (let attempt = 0; attempt < 30; attempt++) {
    try {
      const status = await adminDb.command({ replSetGetStatus: 1 })
      if (
        status.members?.some(
          (member: { stateStr: string }) => member.stateStr === 'PRIMARY'
        )
      ) {
        return
      }
    } catch (error) {
      if (!initiated && isReplicaSetNotInitializedError(error)) {
        await adminDb.command({
          replSetInitiate: {
            _id: REPLICA_SET_NAME,
            members: [{ _id: 0, host: REPLICA_SET_HOST }]
          }
        })
        initiated = true
      }
    }

    await new Promise((resolve) => setTimeout(resolve, 1000))
  }

  throw new Error('Replica set did not reach PRIMARY in time')
}

describe('MongoDB Atlas rule enforcement (e2e)', () => {
  registerMongoAtlasE2eSetup({
    DB_NAME,
    AUTH_USERS_COLLECTION,
    APP_ROOT,
    MANAGE_REPLICA_SET,
    resolveMongoUrl,
    dropReplicaSetHint,
    ensureReplicaSet,
    ensureFilteredTriggerCollections,
    registerAccessToken,
    ownerUser,
    guestUser,
    adminUser,
    authUserIds,
    getClient: () => client,
    setClient: (value) => {
      client = value
    },
    setAppInstance: (value) => {
      appInstance = value
    },
    setOriginalMainPath: (value) => {
      originalMainPath = value
    },
    onBeforeEach: resetCollections
  })

  it('requires authentication to access MongoDB services', async () => {
    await expect(getTodosCollection(null).find({}).toArray()).rejects.toThrow()
  })

  afterAll(async () => {
    await appInstance?.close()
    await client.close()
    if (require.main) {
      require.main.path = originalMainPath
    }
  })

  it('exports only the requesting user todos when reading', async () => {
    const todos = (await getTodosCollection(ownerUser).find({}).toArray()) as TodoDoc[]
    expect(todos).toHaveLength(2)
    expect(todos.every((todo) => todo.userId === ownerUser.id)).toBe(true)
  })

  it('respects projection options in findOne', async () => {
    const todo = (await getTodosCollection(ownerUser).findOne(
      { _id: todoIds.ownerFirst },
      { title: 1, userId: 1 }
    )) as TodoDoc | null

    expect(todo).toBeDefined()
    expect(todo).toMatchObject({
      title: 'Owner task 1',
      userId: ownerUser.id
    })
    expect(todo).not.toHaveProperty('sensitive')
  })

  describe('projection priority between rules and client', () => {
    it('uses only the client projection when rules do not define one (find)', async () => {
      // todos rules.json has no projection: only the client projection must apply.
      // userId is kept because the todoOwner role matches on it.
      const todos = (await getTodosCollection(ownerUser)
        .find({}, { title: 1, userId: 1 })
        .toArray()) as TodoDoc[]
      expect(todos).toHaveLength(2)
      for (const todo of todos) {
        expect(todo).toHaveProperty('title')
        expect(todo).toHaveProperty('userId', ownerUser.id)
        expect(todo).not.toHaveProperty('sensitive')
      }
    })

    it('uses only the client projection when rules do not define one (findOne)', async () => {
      const todo = (await getTodosCollection(ownerUser).findOne(
        { _id: todoIds.ownerFirst },
        { title: 1, userId: 1 }
      )) as TodoDoc | null
      expect(todo).toBeDefined()
      expect(todo).toHaveProperty('title', 'Owner task 1')
      expect(todo).toHaveProperty('userId', ownerUser.id)
      expect(todo).not.toHaveProperty('sensitive')
    })

    it('applies only the rules projection when no client projection is passed (find)', async () => {
      // inventory rules.json defines projection { item: 1, status: 1, "instock.qty": 1 }
      const docs = (await getInventoryCollection(ownerUser)
        .find({})
        .toArray()) as Document[]
      expect(docs).toHaveLength(2)
      for (const doc of docs) {
        expect(doc).toHaveProperty('_id')
        expect(doc).toHaveProperty('item')
        expect(doc).toHaveProperty('status')
        // Nested projection: only instock.qty must be present, warehouse must be stripped.
        expect(doc.instock).toEqual({ qty: expect.any(Number) })
        expect(doc).not.toHaveProperty('ownerId')
        expect(doc).not.toHaveProperty('price')
        expect(doc).not.toHaveProperty('secretCost')
      }
    })

    it('applies only the rules projection when no client projection is passed (findOne)', async () => {
      const doc = (await getInventoryCollection(ownerUser).findOne({
        _id: inventoryIds.ownerApple
      })) as Document | null
      expect(doc).toBeDefined()
      expect(doc).toMatchObject({ item: 'apple', status: 'A' })
      expect(doc?.instock).toEqual({ qty: 120 })
      expect(doc).not.toHaveProperty('price')
      expect(doc).not.toHaveProperty('secretCost')
      expect(doc).not.toHaveProperty('ownerId')
    })

    it('merges client projection with rules projection when fields differ (find)', async () => {
      // Client asks for price; rules include item/status/instock.qty. Both should be present.
      const docs = (await getInventoryCollection(ownerUser)
        .find({}, { price: 1 })
        .toArray()) as Document[]
      expect(docs).toHaveLength(2)
      for (const doc of docs) {
        expect(doc).toHaveProperty('item')
        expect(doc).toHaveProperty('status')
        expect(doc.instock).toEqual({ qty: expect.any(Number) })
        expect(doc).toHaveProperty('price')
        // Fields not requested anywhere stay stripped.
        expect(doc).not.toHaveProperty('secretCost')
        expect(doc).not.toHaveProperty('ownerId')
      }
    })

    it('rules projection wins on conflicting keys (client cannot re-map rules keys)', async () => {
      // Client explicitly tries to re-include a key already present in rules projection
      // alongside a new field. Rules wins on the conflicting key, client adds the new one.
      const doc = (await getInventoryCollection(ownerUser).findOne(
        { _id: inventoryIds.ownerApple },
        { item: 1, price: 1 }
      )) as Document | null

      expect(doc).toBeDefined()
      // Rules-provided keys are preserved as-is.
      expect(doc).toHaveProperty('item', 'apple')
      expect(doc).toHaveProperty('status', 'A')
      expect(doc?.instock).toEqual({ qty: 120 })
      // Client additional field is honoured when not in conflict with rules.
      expect(doc).toHaveProperty('price', 1.99)
      // Sensitive fields never appear.
      expect(doc).not.toHaveProperty('secretCost')
      expect(doc).not.toHaveProperty('ownerId')
    })

    it('rules projection cannot be bypassed via options.projection (find)', async () => {
      // The client attempts to expose secretCost by smuggling it through options.projection.
      const docs = (await getInventoryCollection(ownerUser)
        .find({}, undefined, { projection: { secretCost: 1 } })
        .toArray()) as Document[]
      expect(docs).toHaveLength(2)
      for (const doc of docs) {
        // Rules projection is always applied: item/status/instock.qty are present.
        expect(doc).toHaveProperty('item')
        expect(doc).toHaveProperty('status')
        expect(doc.instock).toEqual({ qty: expect.any(Number) })
        // secretCost is only returned because client asked for it, but critical fields
        // (price, ownerId) the client did not ask for are still excluded.
        expect(doc).not.toHaveProperty('price')
        expect(doc).not.toHaveProperty('ownerId')
      }
    })

    it('rules filter query still restricts the docs returned even with projection merging', async () => {
      // The inventory filter enforces ownerId == user.id. Guest must not see owner docs.
      const guestDocs = (await getInventoryCollection(guestUser)
        .find({}, { price: 1 })
        .toArray()) as Document[]
      expect(guestDocs).toHaveLength(1)
      expect(guestDocs[0]).toHaveProperty('item', 'orange')
      expect(guestDocs[0]).not.toHaveProperty('ownerId')

      // Even when the guest explicitly tries to match owner docs the filter is enforced.
      const sneak = (await getInventoryCollection(guestUser)
        .find({ ownerId: ownerUser.id })
        .toArray()) as Document[]
      expect(sneak).toHaveLength(0)
    })

    it('rules projection supports dotted keys inside findOne', async () => {
      const doc = (await getInventoryCollection(ownerUser).findOne({
        _id: inventoryIds.ownerBanana
      })) as Document | null
      expect(doc).toBeDefined()
      expect(doc?.instock).toEqual({ qty: 40 })
      expect(doc?.instock).not.toHaveProperty('warehouse')
    })

    it('strips a whole sub-tree when rules exclude it, even if the client asked for a dotted sub-path (find)', async () => {
      // Rules projection: { item: 1, status: 1, instock: 0 }
      // Client projection: { item: 1, status: 1, 'instock.qty': 1 }
      // Expected: `instock` must not appear at all in the response.
      const docs = (await getInventoryHiddenCollection(ownerUser)
        .find({}, { item: 1, status: 1, 'instock.qty': 1 })
        .toArray()) as Document[]
      expect(docs).toHaveLength(2)
      for (const doc of docs) {
        expect(doc).toHaveProperty('item')
        expect(doc).toHaveProperty('status')
        expect(doc).not.toHaveProperty('instock')
        expect(doc).not.toHaveProperty('price')
        expect(doc).not.toHaveProperty('ownerId')
      }
    })

    it('strips a whole sub-tree when rules exclude it, even if the client asked for a dotted sub-path (findOne)', async () => {
      const doc = (await getInventoryHiddenCollection(ownerUser).findOne(
        { _id: inventoryHiddenIds.ownerApple },
        { item: 1, status: 1, 'instock.qty': 1 }
      )) as Document | null
      expect(doc).toBeDefined()
      expect(doc).toMatchObject({ item: 'apple', status: 'A' })
      expect(doc).not.toHaveProperty('instock')
    })

    it('ignores every client sub-path attempt under a rules-excluded field', async () => {
      const doc = (await getInventoryHiddenCollection(ownerUser).findOne(
        { _id: inventoryHiddenIds.ownerApple },
        { 'instock.qty': 1, 'instock.warehouse': 1 }
      )) as Document | null
      expect(doc).toBeDefined()
      // Rules-included fields are still returned (rules priority), excluded sub-tree is gone.
      expect(doc).toHaveProperty('item')
      expect(doc).toHaveProperty('status')
      expect(doc).not.toHaveProperty('instock')
    })
  })

  it('denies inserting a todo for another user', async () => {
    await expect(
      getTodosCollection(ownerUser).insertOne({
        title: 'Not allowed',
        userId: guestUser.id
      })
    ).rejects.toThrow('Insert not permitted')
  })

  it('allows owners to insert their own todos', async () => {
    const insertResult = await getTodosCollection(ownerUser).insertOne({
      title: 'New owner task',
      userId: ownerUser.id
    })
    expect(insertResult.insertedId).toBeDefined()
    const inserted = (await getTodosCollection(ownerUser).findOne({
      _id: insertResult.insertedId
    })) as TodoDoc | null
    expect(inserted).toBeDefined()
    expect(inserted?.userId).toBe(ownerUser.id)
  })

  it('applies filters to aggregations as well', async () => {
    const pipeline: Document[] = [
      {
        $group: {
          _id: '$userId',
          count: { $sum: 1 }
        }
      }
    ]

    const summary = (await getTodosCollection(ownerUser)
      .aggregate(pipeline)
      .toArray()) as Array<{
        _id: string
        count: number
      }>

    expect(summary).toHaveLength(1)
    expect(summary[0]).toEqual({ _id: ownerUser.id, count: 2 })
  })

  it('blocks pipelines with disallowed stages in aggregates', async () => {
    const pipeline: Document[] = [
      {
        $out: 'forbidden'
      }
    ]

    await expect(
      getTodosCollection(ownerUser).aggregate(pipeline).toArray()
    ).rejects.toThrow('Stage $out is not allowed in client aggregate pipelines')
  })

  it('requires a pipeline for unionWith in client aggregates', async () => {
    const pipeline: Document[] = [
      {
        $unionWith: 'projects'
      }
    ]

    await expect(
      getTodosCollection(ownerUser).aggregate(pipeline).toArray()
    ).rejects.toThrow('$unionWith must provide a pipeline when called from the client')
  })

  it('applies filters in activityLogs aggregations for non-admin users', async () => {
    const pipeline: Document[] = [
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]

    const summary = (await getActivityLogsCollection(ownerUser)
      .aggregate(pipeline)
      .toArray()) as Array<{ _id: string; count: number }>

    expect(summary).toHaveLength(1)
    expect(summary[0]._id).toBe('active')
  })

  it('allows admins to aggregate all activityLogs', async () => {
    const pipeline: Document[] = [
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]

    const summary = (await getActivityLogsCollection(adminUser)
      .aggregate(pipeline)
      .toArray()) as Array<{ _id: string; count: number }>

    const statuses = summary.map((item) => item._id).sort()
    expect(statuses).toEqual(['active', 'inactive'])
  })

  it('prevents deleting todos that do not belong to the user', async () => {
    await expect(
      getTodosCollection(ownerUser).deleteOne({ _id: todoIds.otherUser })
    ).rejects.toThrow('Delete not permitted')
  })

  it('allows deleting owned todos', async () => {
    const deleteResult = (await getTodosCollection(ownerUser).deleteOne({
      _id: todoIds.ownerFirst
    })) as DeleteResult
    expect(deleteResult.deletedCount).toBe(1)
  })

  it('passes options through deleteOne', async () => {
    await expect(
      getTodosCollection(ownerUser).deleteOne(
        { _id: todoIds.ownerSecond },
        { hint: { missingField: 1 } }
      )
    ).rejects.toThrow()

    const remaining = (await getTodosCollection(ownerUser).findOne({
      _id: todoIds.ownerSecond
    })) as TodoDoc | null
    expect(remaining).toBeDefined()
  })

  it('allows users to delete only their own todos with deleteMany', async () => {
    const deleteResult = (await getTodosCollection(ownerUser).deleteMany(
      {}
    )) as DeleteResult
    expect(deleteResult.deletedCount).toBe(2)

    const remainingOwner = (await getTodosCollection(ownerUser)
      .find({})
      .toArray()) as TodoDoc[]
    expect(remainingOwner).toHaveLength(0)

    const remainingGuest = (await getTodosCollection(guestUser)
      .find({})
      .toArray()) as TodoDoc[]
    expect(remainingGuest).toHaveLength(1)
  })

  it("does not delete others' documents with deleteMany", async () => {
    const deleteResult = (await getTodosCollection(ownerUser).deleteMany({
      userId: guestUser.id
    })) as DeleteResult
    expect(deleteResult.deletedCount).toBe(0)

    const remainingOwner = (await getTodosCollection(ownerUser)
      .find({})
      .toArray()) as TodoDoc[]
    expect(remainingOwner).toHaveLength(2)
  })

  it('allows guests to delete their own todo with deleteOne', async () => {
    const deleteResult = (await getTodosCollection(guestUser).deleteOne({
      _id: todoIds.otherUser
    })) as DeleteResult
    expect(deleteResult.deletedCount).toBe(1)
  })

  it('passes options through deleteMany', async () => {
    await expect(
      getTodosCollection(ownerUser).deleteMany(
        { userId: ownerUser.id },
        { hint: { missingField: 1 } }
      )
    ).rejects.toThrow()

    const remainingOwner = (await getTodosCollection(ownerUser)
      .find({})
      .toArray()) as TodoDoc[]
    expect(remainingOwner).toHaveLength(2)
  })

  it('allows owners to update their own todos with findOneAndUpdate', async () => {
    const updatedTitle = 'Owner task updated'
    await getTodosCollection(ownerUser).findOneAndUpdate(
      { _id: todoIds.ownerFirst },
      { $set: { title: updatedTitle } }
    )

    const updated = (await getTodosCollection(ownerUser).findOne({
      _id: todoIds.ownerFirst
    })) as TodoDoc | null
    expect(updated?.title).toBe(updatedTitle)
  })

  it('prevents guests from updating others todos with findOneAndUpdate', async () => {
    await expect(
      getTodosCollection(guestUser).findOneAndUpdate(
        { _id: todoIds.ownerFirst },
        { $set: { title: 'Should fail' } }
      )
    ).rejects.toThrow('Update not permitted')
  })

  it('limits profiles to shared workspaces', async () => {
    const ownerUsers = (await getUsersCollection(ownerUser)
      .find({})
      .toArray()) as UserDoc[]
    expect(ownerUsers).toHaveLength(1)
    expect(ownerUsers[0].workspaces).toContain('workspace-1')
    expect(ownerUsers[0].userId).toBe(ownerUser.id)

    const guestUsers = (await getUsersCollection(guestUser)
      .find({})
      .toArray()) as UserDoc[]
    expect(guestUsers).toHaveLength(1)
    expect(guestUsers[0].workspaces).toContain('workspace-2')
    expect(guestUsers[0].userId).toBe(guestUser.id)

    const adminUsers = (await getUsersCollection(adminUser)
      .find({})
      .toArray()) as UserDoc[]
    expect(adminUsers).toHaveLength(2)
  })

  it('allows profile updates only for the owner', async () => {
    const updatedName = 'Owner updated'
    const updateResult = await getUsersCollection(ownerUser).updateOne(
      { _id: userIds.owner },
      { $set: { name: updatedName } }
    )
    expect(updateResult.matchedCount).toBe(1)

    const ownerRecord = (await getUsersCollection(ownerUser).findOne({
      _id: userIds.owner
    })) as UserDoc | null
    expect(ownerRecord?.name).toBe(updatedName)

    await expect(
      getUsersCollection(guestUser).updateOne(
        { _id: userIds.owner },
        { $set: { name: 'Hijack' } }
      )
    ).rejects.toThrow('Update not permitted')
  })

  it('blocks access to auth_users collection without rules', async () => {
    await expect(getAuthUsersCollection(ownerUser).find({}).toArray()).rejects.toThrow(
      'READ FORBIDDEN!'
    )
  })

  it('blocks inserts into auth_users without rules', async () => {
    await expect(
      getAuthUsersCollection(ownerUser).insertOne({
        userId: ownerUser.id,
        email: 'blocked@example.com',
        password: 'xxx'
      })
    ).rejects.toThrow('CREATE FORBIDDEN!')
  })

  it('limits projects to the owner and hides forbidden fields', async () => {
    const projects = (await getProjectsCollection(ownerUser)
      .find({})
      .toArray()) as ProjectDoc[]
    expect(projects).toHaveLength(1)
    expect(projects[0].ownerId).toBe(ownerUser.id)
    expect(projects[0]).not.toHaveProperty('secretNotes')
    expect(projects[0]).not.toHaveProperty('internalCode')
    expect(projects[0]).toHaveProperty('summary')
  })

  it('returns only allowed fields when read is undefined and field-level read is configured', async () => {
    const docs = (await getTeamDocsCollection(ownerUser).find({}).toArray()) as TeamDoc[]
    expect(docs).toHaveLength(1)
    expect(docs[0]).toEqual({
      _id: teamDocIds.collaboratorDoc,
      roles: ['editor']
    })

    const singleDoc = (await getTeamDocsCollection(ownerUser).findOne({
      _id: teamDocIds.collaboratorDoc
    })) as TeamDoc | null
    expect(singleDoc).toEqual({
      _id: teamDocIds.collaboratorDoc,
      roles: ['editor']
    })
  })

  it('keeps users fields readable when top-level read is true and fields only define write rules', async () => {
    const ownerRecord = (await getUsersCollection(ownerUser).findOne({
      _id: userIds.owner
    })) as UserDoc | null

    expect(ownerRecord).toEqual({
      _id: userIds.owner,
      userId: ownerUser.id,
      id: authUserIds.owner.toString(),
      email: 'owner@example.com',
      password: 'top-secret',
      workspaces: ['workspace-1'],
      avatar: 'owner.png',
      name: 'Owner name',
      tags: ['owner'],
      updatedAt: expect.any(Date)
    })
  })

  it('allows owners to update their project summary via function rules', async () => {
    const updateResult = await getProjectsCollection(ownerUser).updateOne(
      { _id: projectIds.ownerProject },
      { $set: { summary: 'Updated summary' } }
    )
    expect(updateResult.matchedCount).toBe(1)
    const updated = (await getProjectsCollection(ownerUser).findOne({
      _id: projectIds.ownerProject
    })) as ProjectDoc | null
    expect(updated?.summary).toBe('Updated summary')
  })

  it('prevents guests from updating projects they do not own', async () => {
    await expect(
      getProjectsCollection(guestUser).updateOne(
        { _id: projectIds.ownerProject },
        { $set: { summary: 'Should be blocked' } }
      )
    ).rejects.toThrow('Update not permitted')
  })

  it('lets admins read all projects and see privileged fields', async () => {
    const projects = (await getProjectsCollection(adminUser)
      .find({})
      .toArray()) as ProjectDoc[]
    expect(projects.length).toBeGreaterThanOrEqual(2)
    const ownerProject = projects.find((project) => project.ownerId === ownerUser.id)
    expect(ownerProject).toBeDefined()
    expect(ownerProject).toHaveProperty('secretNotes', 'top secret')
  })

  it('matches role apply_when when document _id is ObjectId and %%user.custom_data.company is string', async () => {
    const ownerDocs = await getOidEqCollection(ownerUser).find({}).toArray()
    expect(ownerDocs).toHaveLength(1)
    expect((ownerDocs[0] as Document)._id).toEqual(oidDocIds.ownerCompany)

    const guestDocs = await getOidEqCollection(guestUser).find({}).toArray()
    expect(guestDocs).toHaveLength(1)
    expect((guestDocs[0] as Document)._id).toEqual(oidDocIds.otherCompany)
  })

  it('supports %stringToOid in apply_when for role matching', async () => {
    const ownerDoc = (await getOidStringToOidCollection(ownerUser).findOne({
      _id: oidDocIds.ownerCompany
    })) as Document | null
    expect(ownerDoc).not.toBeNull()
    expect(ownerDoc?._id).toEqual(oidDocIds.ownerCompany)

    const wrongDoc = (await getOidStringToOidCollection(ownerUser).findOne({
      _id: oidDocIds.otherCompany
    })) as Document | null
    expect(wrongDoc).toEqual({})
  })

  it('supports %oidToString in apply_when for role matching', async () => {
    const ownerDocs = await getOidToStringCollection(ownerUser).find({}).toArray()
    expect(ownerDocs).toHaveLength(1)
    expect((ownerDocs[0] as Document).ownerAuthId).toBe(ownerUser.id)

    const guestDocs = await getOidToStringCollection(guestUser).find({}).toArray()
    expect(guestDocs).toHaveLength(1)
    expect((guestDocs[0] as Document).ownerAuthId).toBe(guestUser.id)
  })

  it('returns only active activity logs for non-admin roles', async () => {
    const logs = (await getActivityLogsCollection(ownerUser)
      .find({})
      .toArray()) as ActivityLogDoc[]
    expect(logs.every((log) => log.status === 'active')).toBe(true)
    expect(logs).toHaveLength(2)
  })

  it('allows admins to read all logs and insert new entries', async () => {
    const logs = (await getActivityLogsCollection(adminUser)
      .find({})
      .toArray()) as ActivityLogDoc[]
    expect(logs.some((log) => log.status === 'inactive')).toBe(true)

    const insertResult = await getActivityLogsCollection(adminUser).insertOne({
      message: 'Admin log',
      status: 'inactive',
      ownerId: adminUser.id
    })
    expect(insertResult.insertedId).toBeDefined()
  })

  it('prevents non-admin users from inserting activity logs', async () => {
    await expect(
      getActivityLogsCollection(ownerUser).insertOne({
        message: 'Blocked log',
        status: 'inactive',
        ownerId: ownerUser.id
      })
    ).rejects.toThrow('Insert not permitted')
  })

  it('allows insert-only roles to insert new documents', async () => {
    const insertResult = await getInsertOnlyCollection(ownerUser).insertOne({
      _id: new ObjectId('000000000000000000000401'),
      ownerId: ownerUser.id,
      title: 'new insert-only doc'
    })

    expect(insertResult.insertedId).toEqual(new ObjectId('000000000000000000000401'))
  })

  it('prevents insert-only roles from reading existing documents', async () => {
    const docId = new ObjectId('000000000000000000000402')
    await client.db(DB_NAME).collection(INSERT_ONLY_COLLECTION).insertOne({
      _id: docId,
      ownerId: ownerUser.id,
      title: 'existing insert-only doc'
    })

    await expect(
      getInsertOnlyCollection(ownerUser).findOne({ _id: docId })
    ).resolves.toEqual({})
  })

  it('prevents insert-only roles from updating existing documents', async () => {
    const docId = new ObjectId('000000000000000000000403')
    await client.db(DB_NAME).collection(INSERT_ONLY_COLLECTION).insertOne({
      _id: docId,
      ownerId: ownerUser.id,
      title: 'existing insert-only doc'
    })

    await expect(
      getInsertOnlyCollection(ownerUser).updateOne(
        { _id: docId },
        { $set: { title: 'blocked update' } }
      )
    ).rejects.toThrow('Update not permitted')
  })

  it('allows admin updateOne upsert with ownerUserId scoped filters in app_settings', async () => {
    const ownerFilter = {
      scope: 'workspace',
      ownerUserId: ownerUser.id
    }
    const ownerSetValues = {
      ownerUserId: ownerUser.id,
      locale: 'en-US',
      updatedAt: '2026-04-02T10:00:00.000Z'
    }

    const updateExistingResult = await getAppSettingsCollection(adminUser).updateOne(
      ownerFilter,
      {
        $set: ownerSetValues,
        $setOnInsert: {
          scope: 'workspace',
          createdAt: '2026-04-02T09:59:00.000Z'
        }
      },
      { upsert: true }
    )

    expect(updateExistingResult.matchedCount).toBe(1)

    const updatedOwnerSettings = (await getAppSettingsCollection(adminUser).findOne(
      ownerFilter
    )) as AppSettingsDoc | null
    expect(updatedOwnerSettings?.locale).toBe('en-US')
    expect(updatedOwnerSettings?.ownerUserId).toBe(ownerUser.id)
    expect(updatedOwnerSettings?.createdAt).toBe('2026-01-01T00:00:00.000Z')

    const guestFilter = {
      scope: 'workspace',
      ownerUserId: guestUser.id
    }
    const guestSetValues = {
      ownerUserId: guestUser.id,
      locale: 'fr-FR',
      updatedAt: '2026-04-02T10:05:00.000Z'
    }

    const upsertInsertResult = await getAppSettingsCollection(adminUser).updateOne(
      guestFilter,
      {
        $set: guestSetValues,
        $setOnInsert: {
          scope: 'workspace',
          createdAt: '2026-04-02T10:04:00.000Z'
        }
      },
      { upsert: true }
    )

    expect(upsertInsertResult.upsertedCount).toBe(1)

    const upsertedGuestSettings = (await getAppSettingsCollection(adminUser).findOne(
      guestFilter
    )) as AppSettingsDoc | null
    expect(upsertedGuestSettings?.locale).toBe('fr-FR')
    expect(upsertedGuestSettings?.ownerUserId).toBe(guestUser.id)
    expect(upsertedGuestSettings?.createdAt).toBe('2026-04-02T10:04:00.000Z')
  })

  it('respects workspace/visibility filters for activities', async () => {
    const ownerActivities = (await getActivitiesCollection(ownerUser)
      .find({})
      .toArray()) as ActivityDoc[]
    expect(ownerActivities).toHaveLength(2)
    expect(
      ownerActivities.every((activity) => activity.workspace === 'workspace-1')
    ).toBe(true)

    const guestActivities = (await getActivitiesCollection(guestUser)
      .find({})
      .toArray()) as ActivityDoc[]
    expect(guestActivities).toHaveLength(1)
    expect(guestActivities[0].workspace).toBe('workspace-2')
  })

  it('restricts activity writes to owner or admin', async () => {
    const newTitle = 'Updated private activity'
    const updateResult = await getActivitiesCollection(ownerUser).updateOne(
      { _id: activityIds.ownerPrivate },
      { $set: { title: newTitle } }
    )
    expect(updateResult.matchedCount).toBe(1)

    const updatedActivity = (await getActivitiesCollection(ownerUser).findOne({
      _id: activityIds.ownerPrivate
    })) as ActivityDoc | null
    expect(updatedActivity?.title).toBe(newTitle)

    await expect(
      getActivitiesCollection(ownerUser).updateOne(
        { _id: activityIds.ownerPublic },
        { $set: { title: 'Blocked change' } }
      )
    ).rejects.toThrow('Update not permitted')

    const adminChange = await getActivitiesCollection(adminUser).updateOne(
      { _id: activityIds.ownerPublic },
      { $set: { title: 'Admin changed' } }
    )
    expect(adminChange.matchedCount).toBe(1)

    const adminActivity = (await getActivitiesCollection(adminUser).findOne({
      _id: activityIds.ownerPublic
    })) as ActivityDoc | null
    expect(adminActivity?.title).toBe('Admin changed')
  })

  it('applies complex visibility filters on counters', async () => {
    const ownerCounters = (await getCountersCollection(ownerUser)
      .find({})
      .toArray()) as CounterDoc[]
    expect(ownerCounters).toHaveLength(3)
    expect(ownerCounters.every((counter) => counter.workspace === 'workspace-1')).toBe(
      true
    )

    const guestCounters = (await getCountersCollection(guestUser)
      .find({})
      .toArray()) as CounterDoc[]
    expect(guestCounters).toHaveLength(1)
    expect(guestCounters[0].visibility.users).toContain(guestUser.id)

    const adminCounters = (await getCountersCollection(adminUser)
      .find({})
      .toArray()) as CounterDoc[]
    expect(adminCounters).toHaveLength(4)
  })

  it('counts accessible counters using RBAC filters', async () => {
    const ownerCount = await getCountersCollection(ownerUser).count({})
    expect(ownerCount).toBe(3)

    const ownerWorkspaceTwoCount = await getCountersCollection(ownerUser).count({
      workspace: 'workspace-2'
    })
    expect(ownerWorkspaceTwoCount).toBe(0)

    const guestCount = await getCountersCollection(guestUser).count({})
    expect(guestCount).toBe(1)

    const guestWorkspaceTwoCount = await getCountersCollection(guestUser).count({
      workspace: 'workspace-2'
    })
    expect(guestWorkspaceTwoCount).toBe(1)

    const adminCount = await getCountersCollection(adminUser).count({})
    expect(adminCount).toBe(4)
  })

  it('supports client aggregate pipelines with $sort/$skip/$limit', async () => {
    const ownerPipeline = [
      { $match: { workspace: 'workspace-1' } },
      { $sort: { value: -1 } },
      { $skip: 1 },
      { $limit: 1 }
    ]
    const ownerResults = (await getCountersCollection(ownerUser)
      .aggregate(ownerPipeline)
      .toArray()) as CounterDoc[]
    expect(ownerResults).toHaveLength(1)
    expect(ownerResults[0].value).toBe(200)

    const guestPipeline = [
      { $match: { workspace: 'workspace-2' } },
      { $sort: { value: 1 } },
      { $skip: 0 },
      { $limit: 1 }
    ]
    const guestResults = (await getCountersCollection(guestUser)
      .aggregate(guestPipeline)
      .toArray()) as CounterDoc[]
    expect(guestResults).toHaveLength(1)
    expect(guestResults[0].workspace).toBe('workspace-2')
  })

  it('supports client find queries with $sort/$skip/$limit options', async () => {
    const ownerResults = (await getCountersCollection(ownerUser)
      .find({}, undefined, { sort: { value: -1 }, skip: 1, limit: 1 })
      .toArray()) as CounterDoc[]
    expect(ownerResults).toHaveLength(1)
    expect(ownerResults[0].value).toBe(200)

    const guestResults = (await getCountersCollection(guestUser)
      .find({}, undefined, { sort: { value: 1 }, limit: 1 })
      .toArray()) as CounterDoc[]
    expect(guestResults).toHaveLength(1)
    expect(guestResults[0].workspace).toBe('workspace-2')
  })

  it('sorts/limits/makes skips work on find and aggregate results with multiple records', async () => {
    const ownerDescPipeline = [
      { $match: { workspace: 'workspace-1' } },
      { $sort: { value: -1 } },
      { $limit: 3 }
    ]
    const ownerDescResults = (await getCountersCollection(ownerUser)
      .aggregate(ownerDescPipeline)
      .toArray()) as CounterDoc[]
    expect(ownerDescResults.length).toBe(3)
    expect(ownerDescResults.map((counter) => counter.value)).toEqual([400, 200, 100])

    const ownerSkipPipeline = [
      { $match: { workspace: 'workspace-1' } },
      { $sort: { value: -1 } },
      { $skip: 1 },
      { $limit: 2 }
    ]
    const ownerSkipResults = (await getCountersCollection(ownerUser)
      .aggregate(ownerSkipPipeline)
      .toArray()) as CounterDoc[]
    expect(ownerSkipResults.map((counter) => counter.value)).toEqual([200, 100])

    const ownerDescFind = (await getCountersCollection(ownerUser)
      .find({}, undefined, { sort: { value: -1 }, limit: 3 })
      .toArray()) as CounterDoc[]
    expect(ownerDescFind.map((counter) => counter.value)).toEqual([400, 200, 100])

    const ownerSkipFind = (await getCountersCollection(ownerUser)
      .find({}, undefined, { sort: { value: -1 }, skip: 1, limit: 2 })
      .toArray()) as CounterDoc[]
    expect(ownerSkipFind.map((counter) => counter.value)).toEqual([200, 100])

    const ownerAscPipeline = [
      { $match: { workspace: 'workspace-1' } },
      { $sort: { value: 1 } },
      { $limit: 3 }
    ]
    const ownerAscResults = (await getCountersCollection(ownerUser)
      .aggregate(ownerAscPipeline)
      .toArray()) as CounterDoc[]
    expect(ownerAscResults.map((counter) => counter.value)).toEqual([100, 200, 400])

    const ownerAscFind = (await getCountersCollection(ownerUser)
      .find({}, undefined, { sort: { value: 1 }, limit: 3 })
      .toArray()) as CounterDoc[]
    expect(ownerAscFind.map((counter) => counter.value)).toEqual([100, 200, 400])
  })

  it('requires admin privileges to modify protected counters', async () => {
    const ownerUpdate = await getCountersCollection(ownerUser).updateOne(
      { _id: counterIds.adminOnly },
      { $set: { value: 450 } }
    )
    expect(ownerUpdate.matchedCount).toBe(1)

    const ownerCounter = (await getCountersCollection(ownerUser).findOne({
      _id: counterIds.adminOnly
    })) as CounterDoc | null
    expect(ownerCounter?.value).toBe(450)

    await expect(
      getCountersCollection(guestUser).updateOne(
        { _id: counterIds.adminOnly },
        { $set: { value: 10 } }
      )
    ).rejects.toThrow('Update not permitted')

    const adminUpdate = await getCountersCollection(adminUser).updateOne(
      { _id: counterIds.adminOnly },
      { $set: { value: 500 } }
    )
    expect(adminUpdate.matchedCount).toBe(1)

    const adminCounter = (await getCountersCollection(adminUser).findOne({
      _id: counterIds.adminOnly
    })) as CounterDoc | null
    expect(adminCounter?.value).toBe(500)
  })

  it('evaluates nested %function inside role apply_when for counters-like rules', async () => {
    const ownerDoc = (await getCountersApplyWhenFunctionCollection(ownerUser).findOne({
      _id: counterApplyWhenFunctionIds.adminWorkspaceDoc
    })) as CounterApplyWhenFunctionDoc | null

    expect(ownerDoc).not.toEqual({})
    expect(ownerDoc?._id).toEqual(counterApplyWhenFunctionIds.adminWorkspaceDoc)
    expect(ownerDoc?.owner).toBe('user-external')

    const ownerUpdate = await getCountersApplyWhenFunctionCollection(ownerUser).updateOne(
      { _id: counterApplyWhenFunctionIds.adminWorkspaceDoc },
      { $set: { value: 615 } }
    )
    expect(ownerUpdate.matchedCount).toBe(1)

    const updatedOwnerDoc =
      (await getCountersApplyWhenFunctionCollection(ownerUser).findOne({
        _id: counterApplyWhenFunctionIds.adminWorkspaceDoc
      })) as CounterApplyWhenFunctionDoc | null
    expect(updatedOwnerDoc?.value).toBe(615)

    const guestDoc = await getCountersApplyWhenFunctionCollection(guestUser).findOne({
      _id: counterApplyWhenFunctionIds.adminWorkspaceDoc
    })
    expect(guestDoc).toBeNull()

    await expect(
      getCountersApplyWhenFunctionCollection(guestUser).updateOne(
        { _id: counterApplyWhenFunctionIds.adminWorkspaceDoc },
        { $set: { value: 999 } }
      )
    ).rejects.toThrow('Update not permitted')
  })

  it('allows status update when the role grants field-level write', async () => {
    const updateResult = await getUploadsCollection(ownerUser).updateOne(
      { _id: uploadIds.owner },
      { $set: { status: 'canceled' } }
    )
    expect(updateResult.matchedCount).toBe(1)

    const updated = (await getUploadsCollection(ownerUser).findOne({
      _id: uploadIds.owner
    })) as UploadDoc | null
    expect(updated?.status).toBe('canceled')
  })

  it('keeps write-only fields readable in find and findOne responses', async () => {
    const found = (await getUploadsCollection(ownerUser).find({}).toArray()) as UploadDoc[]
    expect(found).toHaveLength(1)
    expect(found[0]).toMatchObject({
      _id: uploadIds.owner,
      publisher: ownerUser.custom_data?.key,
      status: 'pending'
    })

    const single = (await getUploadsCollection(ownerUser).findOne({
      _id: uploadIds.owner
    })) as UploadDoc | null
    expect(single).toMatchObject({
      _id: uploadIds.owner,
      publisher: ownerUser.custom_data?.key,
      status: 'pending'
    })
  })

  it('keeps readable the exact Internal role shape with only write permissions on name and address', async () => {
    const found = (await getInternalContactsCollection(ownerUser).find({}).toArray()) as Document[]
    expect(found).toHaveLength(1)
    expect(found[0]).toEqual({
      _id: new ObjectId('000000000000000000000350'),
      name: 'Internal HQ',
      address: 'Via Roma 1'
    })

    const single = await getInternalContactsCollection(ownerUser).findOne({})
    expect(single).toEqual({
      _id: new ObjectId('000000000000000000000350'),
      name: 'Internal HQ',
      address: 'Via Roma 1'
    })
  })

  it('keeps readable the exact Internal role shape with only read permissions on name and address', async () => {
    const found = (await getInternalReadContactsCollection(ownerUser).find({}).toArray()) as Document[]
    expect(found).toHaveLength(1)
    expect(found[0]).toEqual({
      _id: new ObjectId('000000000000000000000351'),
      name: 'Read HQ',
      address: 'Via Milano 2'
    })

    const single = await getInternalReadContactsCollection(ownerUser).findOne({})
    expect(single).toEqual({
      _id: new ObjectId('000000000000000000000351'),
      name: 'Read HQ',
      address: 'Via Milano 2'
    })
  })

  it('triggers activityLogs stream and saves the log', async () => {
    const newActivityId = new ObjectId()
    await getActivityLogsCollection(adminUser).insertOne({
      _id: newActivityId,
      title: 'Trigger test activity',
      ownerId: adminUser.id,
      workspace: 'workspace-1',
      visibility: {
        type: 'team'
      }
    })

    const recorded = await waitForTriggerEvent(newActivityId.toString())
    expect(recorded).not.toBeNull()
    expect(recorded?.operationType).toBe('insert')
    expect(recorded?.documentId).toBe(newActivityId.toString())
  })

  it('fires database trigger on insert', async () => {
    const documentId = new ObjectId()
    await client
      .db(DB_NAME)
      .collection(TRIGGER_ITEMS_INSERT_COLLECTION)
      .insertOne({ _id: documentId, label: 'insert' })

    const event = await waitForTriggerEventType(documentId.toString(), 'insert')
    expect(event).toBeDefined()
    expect(event?.collection).toBe(TRIGGER_ITEMS_INSERT_COLLECTION)
  })

  it('fires database trigger on update', async () => {
    const documentId = new ObjectId()
    await client
      .db(DB_NAME)
      .collection(TRIGGER_ITEMS_UPDATE_COLLECTION)
      .insertOne({ _id: documentId, label: 'before' })

    await client
      .db(DB_NAME)
      .collection(TRIGGER_ITEMS_UPDATE_COLLECTION)
      .updateOne({ _id: documentId }, { $set: { label: 'after' } })

    const event = await waitForTriggerEventType(documentId.toString(), 'update')
    expect(event).toBeDefined()
    expect(event?.collection).toBe(TRIGGER_ITEMS_UPDATE_COLLECTION)
  })

  it('fires database trigger on delete', async () => {
    const documentId = new ObjectId()
    await client
      .db(DB_NAME)
      .collection(TRIGGER_ITEMS_DELETE_COLLECTION)
      .insertOne({ _id: documentId, label: 'delete' })

    await client
      .db(DB_NAME)
      .collection(TRIGGER_ITEMS_DELETE_COLLECTION)
      .deleteOne({ _id: documentId })

    const event = await waitForTriggerEventType(documentId.toString(), 'delete')
    expect(event).toBeDefined()
    expect(event?.collection).toBe(TRIGGER_ITEMS_DELETE_COLLECTION)
  })

  it('passes fullDocument to filtered database triggers when the match applies', async () => {
    const documentId = new ObjectId()
    const payload = {
      _id: documentId,
      label: 'filtered-event',
      category: 'approved',
      ownerId: adminUser.id
    }
    await client
      .db(DB_NAME)
      .collection(FILTERED_TRIGGER_ITEMS_COLLECTION)
      .insertOne(payload)

    const event = await waitForFilteredTriggerEvent(documentId.toString())
    expect(event).toBeDefined()
    expect(event?.type).toBe('insert')
    expect(event?.collection).toBe(FILTERED_TRIGGER_ITEMS_COLLECTION)
    expect(event?.fullDocument).toMatchObject({
      label: 'filtered-event',
      category: 'approved'
    })
  })

  it('does not record filtered events when the match filter does not apply', async () => {
    const documentId = new ObjectId()
    await client.db(DB_NAME).collection(FILTERED_TRIGGER_ITEMS_COLLECTION).insertOne({
      _id: documentId,
      label: 'filtered-event',
      category: 'rejected'
    })

    const event = await waitForFilteredTriggerEvent(documentId.toString())
    expect(event).toBeNull()
  })

  it('records update triggers that include fullDocument and fullDocumentBeforeChange when the filter matches', async () => {
    const documentId = new ObjectId()
    await client.db(DB_NAME).collection(FILTERED_TRIGGER_ITEMS_COLLECTION).insertOne({
      _id: documentId,
      label: 'update-event',
      category: 'pending'
    })

    await client
      .db(DB_NAME)
      .collection(FILTERED_TRIGGER_ITEMS_COLLECTION)
      .updateOne(
        { _id: documentId },
        { $set: { label: 'update-event-approved', category: 'approved' } }
      )

    const event = await waitForFilteredUpdateTriggerEvent(documentId.toString())
    expect(event).toBeDefined()
    expect(event?.type).toBe('update')
    expect(event?.collection).toBe(FILTERED_TRIGGER_ITEMS_COLLECTION)
    expect(event?.fullDocument).toMatchObject({
      label: 'update-event-approved',
      category: 'approved'
    })
    if (event?.fullDocumentBeforeChange) {
      expect(event.fullDocumentBeforeChange).toMatchObject({
        label: 'update-event',
        category: 'pending'
      })
    }
  })

  it('ignores update triggers when the filter does not match', async () => {
    const documentId = new ObjectId()
    await client.db(DB_NAME).collection(FILTERED_TRIGGER_ITEMS_COLLECTION).insertOne({
      _id: documentId,
      label: 'update-event',
      category: 'pending'
    })

    await client
      .db(DB_NAME)
      .collection(FILTERED_TRIGGER_ITEMS_COLLECTION)
      .updateOne(
        { _id: documentId },
        { $set: { label: 'update-event-rejected', category: 'rejected' } }
      )

    const event = await waitForFilteredUpdateTriggerEvent(documentId.toString())
    expect(event).toBeNull()
  })

  it('keeps remaining same-user watchers alive when one tab closes', async () => {
    const first = await openWatchConnection({
      user: ownerUser,
      collection: COUNTERS_COLLECTION
    })
    const second = await openWatchConnection({
      user: ownerUser,
      collection: COUNTERS_COLLECTION
    })

    await first.close()
    await new Promise((resolve) => setTimeout(resolve, 200))

    const insertedId = new ObjectId()
    await client
      .db(DB_NAME)
      .collection(COUNTERS_COLLECTION)
      .insertOne({
        _id: insertedId,
        ownerId: ownerUser.id,
        workspace: 'workspace-1',
        value: 501,
        visibility: { type: 'all' }
      })

    const event = await second.nextEvent()
    expect(event.operationType).toBe('insert')
    expect(String(event.documentKey?._id)).toBe(String(insertedId))

    await second.close()
  })

  it('keeps other users watchers alive when one user disconnects', async () => {
    const ownerWatch = await openWatchConnection({
      user: ownerUser,
      collection: COUNTERS_COLLECTION
    })
    const adminWatch = await openWatchConnection({
      user: adminUser,
      collection: COUNTERS_COLLECTION
    })

    await ownerWatch.close()
    await new Promise((resolve) => setTimeout(resolve, 200))

    const insertedId = new ObjectId()
    await client
      .db(DB_NAME)
      .collection(COUNTERS_COLLECTION)
      .insertOne({
        _id: insertedId,
        ownerId: adminUser.id,
        workspace: 'workspace-1',
        value: 777,
        visibility: { type: 'all' }
      })

    const event = await adminWatch.nextEvent()
    expect(event.operationType).toBe('insert')
    expect(String(event.documentKey?._id)).toBe(String(insertedId))

    await adminWatch.close()
  })

  it('does not under-deliver when a less-privileged user subscribes first', async () => {
    const guestWatch = await openWatchConnection({
      user: guestUser,
      collection: COUNTERS_COLLECTION
    })
    const adminWatch = await openWatchConnection({
      user: adminUser,
      collection: COUNTERS_COLLECTION
    })

    const insertedId = new ObjectId()
    await client
      .db(DB_NAME)
      .collection(COUNTERS_COLLECTION)
      .insertOne({
        _id: insertedId,
        ownerId: adminUser.id,
        workspace: 'workspace-1',
        value: 888,
        visibility: { type: 'private' }
      })

    const adminEvent = await adminWatch.nextEvent()
    expect(String(adminEvent.documentKey?._id)).toBe(String(insertedId))
    await guestWatch.expectNoEvent()

    await guestWatch.close()
    await adminWatch.close()
  })

  it('does not leak events when a privileged user subscribes first', async () => {
    const adminWatch = await openWatchConnection({
      user: adminUser,
      collection: COUNTERS_COLLECTION
    })
    const guestWatch = await openWatchConnection({
      user: guestUser,
      collection: COUNTERS_COLLECTION
    })

    const insertedId = new ObjectId()
    await client
      .db(DB_NAME)
      .collection(COUNTERS_COLLECTION)
      .insertOne({
        _id: insertedId,
        ownerId: adminUser.id,
        workspace: 'workspace-1',
        value: 999,
        visibility: { type: 'private' }
      })

    const adminEvent = await adminWatch.nextEvent()
    expect(String(adminEvent.documentKey?._id)).toBe(String(insertedId))
    await guestWatch.expectNoEvent()

    await adminWatch.close()
    await guestWatch.close()
  })

  it('emits upload watch event only when status changes with a complex change-stream filter', async () => {
    const watch = await openWatchConnection({
      user: ownerUser,
      collection: UPLOADS_COLLECTION,
      filter: {
        'fullDocument.publisher': ownerUser.custom_data?.key,
        $and: [
          {
            $or: [
              { 'fullDocument._id': uploadIds.owner },
              { 'fullDocument._id': uploadIds.owner }
            ]
          },
          {
            $or: [
              { operationType: 'insert' },
              { operationType: 'replace' },
              {
                operationType: 'update',
                'updateDescription.updatedFields.status': { $exists: true }
              }
            ]
          }
        ]
      }
    })

    try {
      await client
        .db(DB_NAME)
        .collection(UPLOADS_COLLECTION)
        .updateOne({ _id: uploadIds.owner }, { $set: { runAt: new Date() } })

      await watch.expectNoEvent()

      await client
        .db(DB_NAME)
        .collection(UPLOADS_COLLECTION)
        .updateOne({ _id: uploadIds.owner }, { $set: { status: 'processing' } })

      const event = await watch.nextEvent()
      expect(event.operationType).toBe('update')
      expect(String(event.documentKey?._id)).toBe(String(uploadIds.owner))
      expect((event.fullDocument as UploadDoc | undefined)?.status).toBe('processing')
    } finally {
      await watch.close()
    }
  })

  it('emits delete watch event when filter combines insert branch and delete branch', async () => {
    const accountId = ownerUser.custom_data?.key
    const requestId = new ObjectId()
    const documentId = new ObjectId()
    const watch = await openWatchConnection({
      user: ownerUser,
      collection: UPLOADS_COLLECTION,
      filter: {
        $or: [
          {
            operationType: 'insert',
            'fullDocument.publisher': accountId,
            'fullDocument.requestId': requestId
          },
          {
            operationType: 'delete'
          }
        ]
      }
    })

    try {
      await client.db(DB_NAME).collection(UPLOADS_COLLECTION).insertOne({
        _id: documentId,
        publisher: accountId,
        status: 'pending'
      })

      await watch.expectNoEvent()

      await client
        .db(DB_NAME)
        .collection(UPLOADS_COLLECTION)
        .deleteOne({ _id: documentId })

      const event = await watch.nextEvent()
      expect(event.operationType).toBe('delete')
      expect(String(event.documentKey?._id)).toBe(String(documentId))
    } finally {
      await watch.close()
    }
  })
  afterAll(async () => {
    await appInstance?.close()
    await client.close()
    if (require.main) {
      require.main.path = originalMainPath
    }
  })
})
